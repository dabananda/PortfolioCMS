import { Loader2, X, User } from 'lucide-react'

// ── Button ────────────────────────────────────────────────────────────
const BTN_BASE = {
  display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
  fontFamily: 'inherit', fontWeight: 500, borderRadius: '7px',
  border: 'none', cursor: 'pointer',
  transition: 'background 0.15s, color 0.15s, border-color 0.15s, opacity 0.15s',
  whiteSpace: 'nowrap', flexShrink: 0,
}
const BTN_SIZES = {
  sm: { padding: '0.35rem 0.8rem',  fontSize: '0.8rem'  },
  md: { padding: '0.5rem 1rem',     fontSize: '0.875rem' },
  lg: { padding: '0.65rem 1.4rem',  fontSize: '0.95rem'  },
}
const BTN_VARIANTS = {
  primary: {
    idle:  { background: '#c8a96e', color: '#0c0c0f' },
    hover: { background: '#d4b87c', color: '#0c0c0f' },
  },
  ghost: {
    idle:  { background: 'transparent', color: 'var(--text-muted)', border: '1px solid var(--border)' },
    hover: { background: 'var(--surface2)', color: 'var(--text)', border: '1px solid var(--border-hover)' },
  },
  danger: {
    idle:  { background: 'var(--red-dim)', color: 'var(--red)', border: '1px solid rgba(224,92,92,0.35)' },
    hover: { background: 'var(--red)', color: '#fff', border: '1px solid var(--red)' },
  },
  link: {
    idle:  { background: 'transparent', color: 'var(--accent)', textDecoration: 'underline', textUnderlineOffset: '3px' },
    hover: { background: 'transparent', color: 'var(--accent-hover)' },
  },
}

export function Btn({ children, variant = 'primary', size = 'md', loading, icon, style: extStyle, disabled, ...props }) {
  const v = BTN_VARIANTS[variant] || BTN_VARIANTS.primary
  return (
    <button
      {...props}
      disabled={disabled || loading}
      style={{ ...BTN_BASE, ...BTN_SIZES[size], ...v.idle, opacity: (disabled || loading) ? 0.5 : 1, ...extStyle }}
      onMouseEnter={e => { if (!disabled && !loading) Object.assign(e.currentTarget.style, v.hover) }}
      onMouseLeave={e => { if (!disabled && !loading) Object.assign(e.currentTarget.style, { ...BTN_BASE, ...BTN_SIZES[size], ...v.idle }) }}
    >
      {loading ? <Loader2 size={14} className="spin" /> : icon}
      {children}
    </button>
  )
}

// ── Card ──────────────────────────────────────────────────────────────
export function Card({ children, style: extStyle, ...props }) {
  return (
    <div
      style={{
        background: 'var(--surface)', border: '1px solid var(--border)',
        borderRadius: '10px', ...extStyle,
      }}
      {...props}
    >
      {children}
    </div>
  )
}

// ── Field ─────────────────────────────────────────────────────────────
export function Field({ label, error, children, required, hint }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
      {label && (
        <label style={{ fontSize: '0.82rem', fontWeight: 500, color: 'var(--text-muted)', letterSpacing: '0.02em' }}>
          {label}{required && <span style={{ color: 'var(--red)', marginLeft: 3 }}>*</span>}
        </label>
      )}
      {children}
      {hint && !error && <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>{hint}</span>}
      {error && <span style={{ fontSize: '0.75rem', color: 'var(--red)' }}>{error}</span>}
    </div>
  )
}

// ── Modal ─────────────────────────────────────────────────────────────
export function Modal({ open, onClose, title, children, width = 520 }) {
  if (!open) return null
  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: '1rem',
    }}>
      <div onClick={e => e.stopPropagation()} className="fade-in" style={{
        background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '10px',
        width: '100%', maxWidth: width, maxHeight: '90vh', overflowY: 'auto',
        boxShadow: '0 8px 40px rgba(0,0,0,0.5)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border)' }}>
          <h3 style={{ fontFamily: "'DM Serif Display', serif", fontSize: '1.1rem' }}>{title}</h3>
          <button onClick={onClose} style={{ color: 'var(--text-muted)', display: 'flex', padding: 4, borderRadius: 6, background: 'none', border: 'none', cursor: 'pointer', transition: 'color 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--text)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
          ><X size={18} /></button>
        </div>
        <div style={{ padding: '1.5rem' }}>{children}</div>
      </div>
    </div>
  )
}

// ── Confirm Dialog ────────────────────────────────────────────────────
export function ConfirmDialog({ open, onClose, onConfirm, title, message, loading }) {
  return (
    <Modal open={open} onClose={onClose} title={title || 'Confirm'} width={400}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', lineHeight: 1.6 }}>{message}</p>
        <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
          <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          <Btn variant="danger" onClick={onConfirm} loading={loading}>Delete</Btn>
        </div>
      </div>
    </Modal>
  )
}

// ── Badge ─────────────────────────────────────────────────────────────
const BADGE_STYLES = {
  default: { background: 'var(--surface2)', color: 'var(--text-muted)' },
  accent:  { background: 'var(--accent-dim)', color: 'var(--accent)' },
  green:   { background: 'var(--green-dim)', color: 'var(--green)' },
  red:     { background: 'var(--red-dim)', color: 'var(--red)' },
  blue:    { background: 'var(--blue-dim)', color: 'var(--blue)' },
}
export function Badge({ children, color = 'default' }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 8px', borderRadius: 20,
      fontSize: '0.72rem', fontWeight: 500, letterSpacing: '0.03em',
      ...BADGE_STYLES[color],
    }}>
      {children}
    </span>
  )
}

// ── Avatar ────────────────────────────────────────────────────────────
export function Avatar({ src, name, size = 36 }) {
  const initials = name ? name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() : '?'
  if (src) {
    return (
      <img
        src={src} alt={name || 'avatar'}
        onError={e => { e.currentTarget.style.display = 'none'; e.currentTarget.nextSibling.style.display = 'flex' }}
        style={{ width: size, height: size, borderRadius: '50%', objectFit: 'cover', flexShrink: 0, display: 'block' }}
      />
    )
  }
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%', background: 'var(--accent-dim)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: 'var(--accent)', fontWeight: 600, fontSize: size * 0.35,
      flexShrink: 0, letterSpacing: '-0.02em',
    }}>
      {initials}
    </div>
  )
}

// ── SafeImg — always renders, falls back to placeholder ───────────────
export function SafeImg({ src, alt, style: s, fallback }) {
  if (!src) return fallback || null
  return (
    <img
      src={src} alt={alt || ''}
      style={s}
      onError={e => {
        e.currentTarget.style.display = 'none'
        if (e.currentTarget.nextSibling) e.currentTarget.nextSibling.style.display = 'flex'
      }}
    />
  )
}

// ── Empty state ───────────────────────────────────────────────────────
export function Empty({ icon: Icon, title, subtitle, action }) {
  return (
    <div style={{ textAlign: 'center', padding: '3rem 1rem', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.75rem' }}>
      {Icon && (
        <div style={{ width: 48, height: 48, borderRadius: 12, background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-dim)', marginBottom: 4 }}>
          <Icon size={22} />
        </div>
      )}
      <p style={{ color: 'var(--text-muted)', fontWeight: 500 }}>{title}</p>
      {subtitle && <p style={{ color: 'var(--text-dim)', fontSize: '0.85rem' }}>{subtitle}</p>}
      {action}
    </div>
  )
}

// ── Spinner ───────────────────────────────────────────────────────────
export function Spinner({ size = 24 }) {
  return <Loader2 size={size} className="spin" style={{ color: 'var(--accent)' }} />
}

// ── Section header ────────────────────────────────────────────────────
export function SectionHeader({ title, subtitle, action }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '1rem', marginBottom: '1.75rem', flexWrap: 'wrap' }}>
      <div>
        <h2 style={{ fontSize: '1.4rem', marginBottom: 2 }}>{title}</h2>
        {subtitle && <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', marginTop: 2 }}>{subtitle}</p>}
      </div>
      {action}
    </div>
  )
}

// ── Error message extractor ───────────────────────────────────────────
export function getErrMsg(err) {
  return err?.response?.data?.message || err?.message || 'Something went wrong'
}
