import { useRef, useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import {
  LayoutDashboard, User, FileText, Tag, Briefcase, GraduationCap,
  Award, Link2, Star, MessageSquare, Code2, Activity, Settings,
  LogOut, Menu, X, ExternalLink,
} from 'lucide-react'

const NAV = [
  { group: 'Overview', items: [
    { to: '/dashboard',          icon: LayoutDashboard, label: 'Dashboard'      },
    { to: '/dashboard/messages', icon: MessageSquare,   label: 'Messages'       },
  ]},
  { group: 'Content', items: [
    { to: '/dashboard/blog',       icon: FileText,  label: 'Blog Posts'  },
    { to: '/dashboard/categories', icon: Tag,       label: 'Categories'  },
    { to: '/dashboard/projects',   icon: Briefcase, label: 'Projects'    },
  ]},
  { group: 'Profile', items: [
    { to: '/dashboard/profile',         icon: User,          label: 'My Profile'     },
    { to: '/dashboard/skills',          icon: Code2,         label: 'Skills'         },
    { to: '/dashboard/education',       icon: GraduationCap, label: 'Education'      },
    { to: '/dashboard/work',            icon: Briefcase,     label: 'Work Exp.'      },
    { to: '/dashboard/certifications',  icon: Award,         label: 'Certifications' },
    { to: '/dashboard/social',          icon: Link2,         label: 'Social Links'   },
    { to: '/dashboard/reviews',         icon: Star,          label: 'Reviews'        },
    { to: '/dashboard/activities',      icon: Activity,      label: 'Activities'     },
    { to: '/dashboard/problem-solving', icon: Code2,         label: 'Problem Solving'},
  ]},
  { group: 'Account', items: [
    { to: '/dashboard/settings', icon: Settings, label: 'Settings' },
  ]},
]

// ─── Sidebar is defined OUTSIDE Layout so it never remounts on navigation ────
function Sidebar({ user, onLogout, onClose, mobile = false }) {
  return (
    <aside style={{
      width: mobile ? 260 : 232,
      background: 'var(--surface)',
      borderRight: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column',
      height: '100%', flexShrink: 0,
      ...(mobile ? { position: 'fixed', top: 0, left: 0, bottom: 0, zIndex: 200 } : {}),
    }}>
      {/* ── Logo + user ── */}
      <div style={{ padding: '1.25rem 1.25rem 1rem', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: "'DM Serif Display', serif", fontSize: '1.15rem', color: '#c8a96e' }}>
            Portfolio<span style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>CMS</span>
          </span>
          {mobile && (
            <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex', padding: 4 }}>
              <X size={18} />
            </button>
          )}
        </div>

        {/* User chip */}
        <div style={{ marginTop: '1rem', display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          {user?.imageUrl ? (
            <img
              src={user.imageUrl} alt="avatar"
              onError={e => { e.currentTarget.style.display = 'none'; e.currentTarget.nextSibling.style.display = 'flex' }}
              style={{ width: 34, height: 34, borderRadius: '50%', objectFit: 'cover', flexShrink: 0 }}
            />
          ) : null}
          <div style={{
            width: 34, height: 34, borderRadius: '50%',
            background: 'var(--accent-dim)',
            display: user?.imageUrl ? 'none' : 'flex',
            alignItems: 'center', justifyContent: 'center',
            color: '#c8a96e', fontWeight: 600, fontSize: '0.82rem', flexShrink: 0,
          }}>
            {(user?.firstName?.[0] || '') + (user?.lastName?.[0] || '')}
          </div>
          <div style={{ overflow: 'hidden', flex: 1 }}>
            <p style={{ fontSize: '0.82rem', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {user?.firstName} {user?.lastName}
            </p>
            <p style={{ fontSize: '0.71rem', color: 'var(--text-dim)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {user?.email || user?.username}
            </p>
          </div>
        </div>
      </div>

      {/* ── Nav ── */}
      <nav style={{ flex: 1, overflowY: 'auto', padding: '0.5rem 0', scrollbarWidth: 'thin' }}>
        {NAV.map(({ group, items }) => (
          <div key={group} style={{ marginBottom: '0.1rem' }}>
            <p style={{
              fontSize: '0.66rem', fontWeight: 700, letterSpacing: '0.09em',
              color: 'var(--text-dim)', textTransform: 'uppercase',
              padding: '0.65rem 1.25rem 0.25rem',
            }}>
              {group}
            </p>
            {items.map(({ to, icon: Icon, label }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/dashboard'}
                onClick={mobile ? onClose : undefined}
                style={({ isActive }) => ({
                  display: 'flex', alignItems: 'center', gap: '0.6rem',
                  padding: '0.45rem 1.1rem 0.45rem 1.25rem',
                  fontSize: '0.845rem', fontFamily: 'inherit',
                  color:      isActive ? '#c8a96e' : 'var(--text-muted)',
                  background: isActive ? 'rgba(200,169,110,0.07)' : 'transparent',
                  borderRight: `2px solid ${isActive ? '#c8a96e' : 'transparent'}`,
                  transition: 'color 0.15s, background 0.15s',
                  textDecoration: 'none',
                })}
                onMouseEnter={e => {
                  if (!e.currentTarget.getAttribute('aria-current'))
                    e.currentTarget.style.color = 'var(--text)'
                }}
                onMouseLeave={e => {
                  if (!e.currentTarget.getAttribute('aria-current'))
                    e.currentTarget.style.color = 'var(--text-muted)'
                }}
              >
                <Icon size={15} style={{ flexShrink: 0 }} />
                {label}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      {/* ── View Portfolio ── */}
      {(
        <div style={{ padding: '0.5rem 1.25rem 0', flexShrink: 0 }}>
          <a
            href="/"
            target="_blank"
            rel="noreferrer"
            style={{
              display: 'flex', alignItems: 'center', gap: '0.55rem',
              fontSize: '0.835rem', color: '#c8a96e', textDecoration: 'none',
              padding: '0.4rem 0', transition: 'opacity 0.15s',
            }}
            onMouseEnter={e => e.currentTarget.style.opacity = '0.7'}
            onMouseLeave={e => e.currentTarget.style.opacity = '1'}
          >
            <ExternalLink size={13} /> View my portfolio
          </a>
        </div>
      )}

      {/* ── Logout ── */}
      <div style={{ padding: '0.75rem 1.25rem', borderTop: '1px solid var(--border)', flexShrink: 0 }}>
        <button
          onClick={onLogout}
          style={{
            display: 'flex', alignItems: 'center', gap: '0.6rem',
            fontSize: '0.845rem', fontFamily: 'inherit', background: 'none', border: 'none',
            cursor: 'pointer', color: 'var(--text-muted)', width: '100%',
            padding: '0.35rem 0', transition: 'color 0.15s',
          }}
          onMouseEnter={e => e.currentTarget.style.color = 'var(--red)'}
          onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
        >
          <LogOut size={15} /> Sign out
        </button>
      </div>
    </aside>
  )
}

// ─── Main Layout ──────────────────────────────────────────────────────
export default function Layout({ children }) {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [mobileOpen, setMobileOpen] = useState(false)

  const handleLogout = () => { logout(); navigate('/login') }

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>

      {/* Desktop sidebar — always mounted, never re-created */}
      <div className="sidebar-desktop-wrapper">
        <Sidebar user={user} onLogout={handleLogout} />
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <>
          <div
            onClick={() => setMobileOpen(false)}
            style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.65)', zIndex: 199 }}
          />
          <Sidebar user={user} onLogout={handleLogout} onClose={() => setMobileOpen(false)} mobile />
        </>
      )}

      {/* Main content area */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>

        {/* Mobile topbar */}
        <header className="mobile-topbar" style={{
          display: 'none', alignItems: 'center', gap: '1rem',
          padding: '0.7rem 1rem', borderBottom: '1px solid var(--border)',
          background: 'var(--surface)', flexShrink: 0,
        }}>
          <button
            onClick={() => setMobileOpen(true)}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex' }}
          >
            <Menu size={20} />
          </button>
          <span style={{ fontFamily: "'DM Serif Display', serif", fontSize: '1.05rem', color: '#c8a96e' }}>
            PortfolioCMS
          </span>
        </header>

        {/* Page content */}
        <main style={{ flex: 1, overflowY: 'auto', padding: '2rem' }}>
          {children}
        </main>
      </div>

      <style>{`
        .sidebar-desktop-wrapper { display: flex; }
        .mobile-topbar           { display: none !important; }
        @media (max-width: 767px) {
          .sidebar-desktop-wrapper { display: none !important; }
          .mobile-topbar           { display: flex !important; }
          main { padding: 1.25rem !important; }
        }
      `}</style>
    </div>
  )
}
