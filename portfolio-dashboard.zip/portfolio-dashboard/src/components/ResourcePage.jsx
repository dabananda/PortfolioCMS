import { useState, useCallback, useEffect } from 'react'
import { Btn, Card, Modal, SectionHeader, Empty, Spinner, ConfirmDialog, getErrMsg } from './ui'
import toast from 'react-hot-toast'
import { Plus, Edit2, Trash2 } from 'lucide-react'

// ── Generic CRUD page used by Skills, Projects, Education, etc. ───────
export function ResourcePage({
  title, subtitle, icon: Icon, api,
  renderForm, renderRow,
  emptyTitle, emptySubtitle, formWidth = 480,
}) {
  const [items, setItems]     = useState([])
  const [loading, setLoading] = useState(true)
  const [modal, setModal]     = useState(null)   // null | { item: obj|null }
  const [deleting, setDeleting] = useState(null)
  const [actionLoading, setActionLoading] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await api.getAll()
      const raw = data.data
      setItems(Array.isArray(raw) ? raw : raw?.items || [])
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setLoading(false) }
  }, [api])

  useEffect(() => { load() }, [load])

  const handleSave = async form => {
    if (modal.item) {
      const { data } = await api.update(modal.item.id, form)
      setItems(p => p.map(x => x.id === data.data.id ? data.data : x))
      toast.success('Updated')
    } else {
      const { data } = await api.create(form)
      setItems(p => [...p, data.data])
      toast.success('Created')
    }
    setModal(null)
  }

  const handleDelete = async () => {
    setActionLoading(true)
    try {
      await api.delete(deleting.id)
      setItems(p => p.filter(x => x.id !== deleting.id))
      toast.success('Deleted'); setDeleting(null)
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setActionLoading(false) }
  }

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', paddingTop: '4rem' }}>
      <Spinner size={32} />
    </div>
  )

  return (
    <div className="fade-in" style={{ maxWidth: 820 }}>
      <SectionHeader
        title={title}
        subtitle={`${items.length} item${items.length !== 1 ? 's' : ''}${subtitle ? ' · ' + subtitle : ''}`}
        action={
          <Btn icon={<Plus size={15} />} onClick={() => setModal({ item: null })}>
            Add new
          </Btn>
        }
      />

      <Card>
        {items.length === 0 ? (
          <Empty
            icon={Icon}
            title={emptyTitle || `No ${title.toLowerCase()} yet`}
            subtitle={emptySubtitle}
            action={
              <Btn size="sm" icon={<Plus size={14} />} onClick={() => setModal({ item: null })}>
                Add first
              </Btn>
            }
          />
        ) : items.map((item, i) => (
          <div key={item.id} style={{
            display: 'flex', alignItems: 'flex-start', gap: '0.75rem',
            padding: '0.95rem 1.25rem',
            borderBottom: i < items.length - 1 ? '1px solid var(--border)' : 'none',
          }}>
            <div style={{ flex: 1, minWidth: 0 }}>{renderRow(item)}</div>

            {/* Actions */}
            <div style={{ display: 'flex', gap: '0.25rem', flexShrink: 0, paddingTop: 2 }}>
              <IconBtn onClick={() => setModal({ item })} hoverColor="var(--text)">
                <Edit2 size={14} />
              </IconBtn>
              <IconBtn onClick={() => setDeleting(item)} hoverColor="var(--red)">
                <Trash2 size={14} />
              </IconBtn>
            </div>
          </div>
        ))}
      </Card>

      {/* Create / Edit modal */}
      <Modal
        open={!!modal}
        onClose={() => setModal(null)}
        title={modal?.item ? `Edit ${singular(title)}` : `Add ${singular(title)}`}
        width={formWidth}
      >
        {modal && (
          <FormWrapper
            initial={modal.item}
            onSave={handleSave}
            onClose={() => setModal(null)}
            renderForm={renderForm}
          />
        )}
      </Modal>

      {/* Delete confirmation */}
      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={handleDelete}
        title={`Delete ${singular(title)}`}
        message="This action cannot be undone."
        loading={actionLoading}
      />
    </div>
  )
}

// ── Tiny icon button ──────────────────────────────────────────────────
function IconBtn({ children, onClick, hoverColor }) {
  return (
    <button
      onClick={onClick}
      style={{
        background: 'none', border: 'none', cursor: 'pointer',
        padding: '5px', borderRadius: 6, display: 'flex',
        color: 'var(--text-dim)', transition: 'color 0.15s',
      }}
      onMouseEnter={e => e.currentTarget.style.color = hoverColor}
      onMouseLeave={e => e.currentTarget.style.color = 'var(--text-dim)'}
    >
      {children}
    </button>
  )
}

// ── Controlled form wrapper ───────────────────────────────────────────
function FormWrapper({ initial, onSave, onClose, renderForm }) {
  const [form, setForm]   = useState(initial ? { ...initial } : {})
  const [saving, setSaving] = useState(false)

  const set    = k => e    => setForm(f => ({ ...f, [k]: e.target.value }))
  const setVal = k => v    => setForm(f => ({ ...f, [k]: v }))

  const handleSubmit = async e => {
    e.preventDefault(); setSaving(true)
    try { await onSave(form) }
    catch (err) { toast.error(getErrMsg(err)); setSaving(false) }
  }

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      {renderForm(form, set, setVal)}
      <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', paddingTop: '0.5rem' }}>
        <Btn type="button" variant="ghost" onClick={onClose}>Cancel</Btn>
        <Btn type="submit" loading={saving}>{initial ? 'Save changes' : 'Create'}</Btn>
      </div>
    </form>
  )
}

function singular(s) { return s.replace(/ies$/,'y').replace(/s$/,'') }
