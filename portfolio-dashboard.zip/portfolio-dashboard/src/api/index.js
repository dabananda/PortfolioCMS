import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api/v1'

export const api = axios.create({ baseURL: BASE_URL })

// Attach token to every request
api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('accessToken')
  if (token) cfg.headers.Authorization = `Bearer ${token}`
  return cfg
})

// Auto-refresh token on 401
api.interceptors.response.use(
  r => r,
  async err => {
    const orig = err.config
    if (err.response?.status === 401 && !orig._retry) {
      orig._retry = true
      const refresh = localStorage.getItem('refreshToken')
      if (refresh) {
        try {
          const { data } = await axios.post(`${BASE_URL}/auth/refresh`, { refreshToken: refresh })
          const token = data.data.accessToken
          localStorage.setItem('accessToken', token)
          if (data.data.refreshToken) localStorage.setItem('refreshToken', data.data.refreshToken)
          orig.headers.Authorization = `Bearer ${token}`
          return api(orig)
        } catch {
          localStorage.clear()
          window.location.href = '/login'
        }
      }
    }
    return Promise.reject(err)
  }
)

// ── Auth ──────────────────────────────────────────────────────────────
export const authApi = {
  login: (data) => api.post('/auth/login', data),
  register: (data) => api.post('/auth/register', data),
  forgotPassword: (email) => api.post('/auth/forgot-password', { email }),
  resetPassword: (data) => api.post('/auth/reset-password', data),
  refresh: (refreshToken) => api.post('/auth/refresh', { refreshToken }),
  checkUsername: (username) => api.get(`/auth/check-username?username=${username}`),
}

// ── Account ───────────────────────────────────────────────────────────
export const accountApi = {
  changePassword: (data) => api.post('/account/change-password', data),
  updateName: (data) => api.put('/account/update-name', data),
  deleteAccount: () => api.delete('/account'),
}

// ── User Profile ──────────────────────────────────────────────────────
export const profileApi = {
  get: () => api.get('/userprofile'),
  create: (data) => api.post('/userprofile', data),
  update: (data) => api.put('/userprofile', data),
}

// ── Blog Posts ────────────────────────────────────────────────────────
export const blogApi = {
  getAll: (params) => api.get('/blogpost', { params }),
  getById: (id) => api.get(`/blogpost/${id}`),
  create: (data) => api.post('/blogpost', data),
  update: (id, data) => api.put(`/blogpost/${id}`, data),
  publish: (id) => api.patch(`/blogpost/${id}/publish`),
  unpublish: (id) => api.patch(`/blogpost/${id}/unpublish`),
  delete: (id) => api.delete(`/blogpost/${id}`),
}

// ── Blog Categories ───────────────────────────────────────────────────
export const categoryApi = {
  getAll: () => api.get('/blogpostcategory'),
  getById: (id) => api.get(`/blogpostcategory/${id}`),
  create: (data) => api.post('/blogpostcategory', data),
  update: (id, data) => api.put(`/blogpostcategory/${id}`, data),
  delete: (id) => api.delete(`/blogpostcategory/${id}`),
}

// ── Skills ────────────────────────────────────────────────────────────
export const skillApi = {
  getAll: () => api.get('/skill'),
  create: (data) => api.post('/skill', data),
  update: (id, data) => api.put(`/skill/${id}`, data),
  delete: (id) => api.delete(`/skill/${id}`),
}

// ── Projects ──────────────────────────────────────────────────────────
export const projectApi = {
  getAll: () => api.get('/project'),
  create: (data) => api.post('/project', data),
  update: (id, data) => api.put(`/project/${id}`, data),
  delete: (id) => api.delete(`/project/${id}`),
}

// ── Education ─────────────────────────────────────────────────────────
export const educationApi = {
  getAll: () => api.get('/education'),
  create: (data) => api.post('/education', data),
  update: (id, data) => api.put(`/education/${id}`, data),
  delete: (id) => api.delete(`/education/${id}`),
}

// ── Work Experience ───────────────────────────────────────────────────
export const workApi = {
  getAll: () => api.get('/workexperience'),
  create: (data) => api.post('/workexperience', data),
  update: (id, data) => api.put(`/workexperience/${id}`, data),
  delete: (id) => api.delete(`/workexperience/${id}`),
}

// ── Certifications ────────────────────────────────────────────────────
export const certApi = {
  getAll: () => api.get('/certification'),
  create: (data) => api.post('/certification', data),
  update: (id, data) => api.put(`/certification/${id}`, data),
  delete: (id) => api.delete(`/certification/${id}`),
}

// ── Social Links ──────────────────────────────────────────────────────
export const socialApi = {
  getAll: () => api.get('/sociallink'),
  create: (data) => api.post('/sociallink', data),
  update: (id, data) => api.put(`/sociallink/${id}`, data),
  delete: (id) => api.delete(`/sociallink/${id}`),
}

// ── Reviews ───────────────────────────────────────────────────────────
export const reviewApi = {
  getAll: () => api.get('/review'),
  create: (data) => api.post('/review', data),
  update: (id, data) => api.put(`/review/${id}`, data),
  delete: (id) => api.delete(`/review/${id}`),
}

// ── Contact Messages ──────────────────────────────────────────────────
export const contactApi = {
  getAll: (params) => api.get('/contactmessage', { params }),
  getById: (id) => api.get(`/contactmessage/${id}`),
  markAsRead: (id) => api.patch(`/contactmessage/${id}/mark-as-read`),
  delete: (id) => api.delete(`/contactmessage/${id}`),
}

// ── Problem Solving ───────────────────────────────────────────────────
export const problemApi = {
  getAll: () => api.get('/problemsolving'),
  create: (data) => api.post('/problemsolving', data),
  update: (id, data) => api.put(`/problemsolving/${id}`, data),
  delete: (id) => api.delete(`/problemsolving/${id}`),
}

// ── Extra Curricular ──────────────────────────────────────────────────
export const activityApi = {
  getAll: () => api.get('/extracurricularactivity'),
  create: (data) => api.post('/extracurricularactivity', data),
  update: (id, data) => api.put(`/extracurricularactivity/${id}`, data),
  delete: (id) => api.delete(`/extracurricularactivity/${id}`),
}

// ── Upload ────────────────────────────────────────────────────────────
export const uploadApi = {
  image: (file) => {
    const fd = new FormData(); fd.append('file', file)
    return api.post('/upload/image', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  resume: (file) => {
    const fd = new FormData(); fd.append('file', file)
    return api.post('/upload/resume', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
}

// ── Public Portfolio (no auth) ────────────────────────────────────────
export const portfolioApi = {
  get:        (username)              => api.get(`/portfolio/${username}`),
  getBlog:    (username, params)      => api.get(`/portfolio/${username}/blog`, { params }),
  getBlogPost:(username, slug)        => api.get(`/portfolio/${username}/blog/${slug}`),
  contact:    (username, data)        => api.post(`/contactmessage`, data),   // auth not required on public contact
}
