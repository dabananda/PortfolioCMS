// Central config — read from .env at build time
export const API_URL           = import.meta.env.VITE_API_URL || 'http://localhost:5000/api/v1'
export const PORTFOLIO_USERNAME = import.meta.env.VITE_PORTFOLIO_USERNAME || ''
