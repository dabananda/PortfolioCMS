import { useState } from 'react'
import { Link } from 'react-router-dom'
import { authApi } from '../../api'
import { Btn, Field, getErrMsg } from '../../components/ui'
import toast from 'react-hot-toast'
import { MailCheck } from 'lucide-react'

export default function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!email) return toast.error('Enter your email address')
    setLoading(true)
    try {
      await authApi.forgotPassword(email)
      setSent(true)
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setLoading(false) }
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)', padding: '1rem' }}>
      <div  style={{ width: '100%', maxWidth: 400 }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <h1 style={{ fontSize: '1.8rem', color: 'var(--accent)', marginBottom: '0.4rem' }}>PortfolioCMS</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>Reset your password</p>
        </div>
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '2rem', boxShadow: 'var(--shadow)' }}>
          {sent ? (
            <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem' }}>
              <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'var(--green-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--green)' }}>
                <MailCheck size={24} />
              </div>
              <h3 style={{ fontFamily: "'DM Serif Display', serif" }}>Check your inbox</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem' }}>If that email exists, we've sent a reset link.</p>
              <Link to="/login" style={{ color: 'var(--accent)', fontSize: '0.88rem' }}>← Back to login</Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <Field label="Email address" required>
                <input type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
              </Field>
              <Btn type="submit" loading={loading} style={{ width: '100%', justifyContent: 'center' }}>
                Send reset link
              </Btn>
              <p style={{ textAlign: 'center', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                <Link to="/login" style={{ color: 'var(--accent)' }}>← Back to login</Link>
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
