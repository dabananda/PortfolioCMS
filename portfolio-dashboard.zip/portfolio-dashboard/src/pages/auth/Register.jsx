import { useState, useEffect, useRef } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { authApi } from '../../api'
import { Btn, Field, getErrMsg } from '../../components/ui'
import toast from 'react-hot-toast'
import { Eye, EyeOff, Check, X } from 'lucide-react'

export default function Register() {
  const navigate = useNavigate()
  const [form, setForm] = useState({ firstName: '', lastName: '', username: '', email: '', password: '' })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState({})
  const [usernameStatus, setUsernameStatus] = useState(null) // null | 'checking' | 'available' | 'taken'
  const usernameTimer = useRef(null)

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  useEffect(() => {
    if (!form.username || form.username.length < 3) { setUsernameStatus(null); return }
    clearTimeout(usernameTimer.current)
    setUsernameStatus('checking')
    usernameTimer.current = setTimeout(async () => {
      try {
        const { data } = await authApi.checkUsername(form.username)
        setUsernameStatus(data.data.available ? 'available' : 'taken')
      } catch { setUsernameStatus(null) }
    }, 600)
    return () => clearTimeout(usernameTimer.current)
  }, [form.username])

  const validate = () => {
    const e = {}
    if (!form.firstName.trim()) e.firstName = 'Required'
    if (!form.lastName.trim()) e.lastName = 'Required'
    if (!form.username.trim()) e.username = 'Required'
    else if (usernameStatus === 'taken') e.username = 'Username already taken'
    if (!form.email.trim()) e.email = 'Required'
    if (!form.password || form.password.length < 6) e.password = 'Min 6 characters'
    setErrors(e); return !Object.keys(e).length
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!validate()) return
    setLoading(true)
    try {
      await authApi.register(form)
      toast.success('Account created! Please check your email to confirm.')
      navigate('/login')
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setLoading(false) }
  }

  const UsernameIndicator = () => {
    if (usernameStatus === 'checking') return <span style={{ fontSize: '0.72rem', color: 'var(--text-dim)' }}>Checking…</span>
    if (usernameStatus === 'available') return <span style={{ fontSize: '0.72rem', color: 'var(--green)', display: 'flex', alignItems: 'center', gap: 3 }}><Check size={11} /> Available</span>
    if (usernameStatus === 'taken') return <span style={{ fontSize: '0.72rem', color: 'var(--red)', display: 'flex', alignItems: 'center', gap: 3 }}><X size={11} /> Taken</span>
    return null
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)', padding: '1.5rem 1rem' }}>
      <div style={{ position: 'fixed', bottom: '-20%', left: '-10%', width: 500, height: 500, borderRadius: '50%', background: 'radial-gradient(circle, rgba(200,169,110,0.05) 0%, transparent 70%)', pointerEvents: 'none' }} />

      <div  style={{ width: '100%', maxWidth: 460 }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <h1 style={{ fontSize: '1.8rem', color: 'var(--accent)', marginBottom: '0.4rem' }}>PortfolioCMS</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>Create your portfolio account</p>
        </div>

        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '2rem', boxShadow: 'var(--shadow)' }}>
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <Field label="First Name" error={errors.firstName} required>
                <input placeholder="John" value={form.firstName} onChange={set('firstName')} />
              </Field>
              <Field label="Last Name" error={errors.lastName} required>
                <input placeholder="Doe" value={form.lastName} onChange={set('lastName')} />
              </Field>
            </div>

            <Field label="Username" error={errors.username} required hint=" " >
              <div style={{ position: 'relative' }}>
                <input placeholder="johndoe" value={form.username} onChange={set('username')} />
                <div style={{ position: 'absolute', right: '0.75rem', top: '50%', transform: 'translateY(-50%)' }}>
                  <UsernameIndicator />
                </div>
              </div>
            </Field>

            <Field label="Email" error={errors.email} required>
              <input type="email" placeholder="you@example.com" value={form.email} onChange={set('email')} />
            </Field>

            <Field label="Password" error={errors.password} required>
              <div style={{ position: 'relative' }}>
                <input type={showPw ? 'text' : 'password'} placeholder="Min 6 characters" value={form.password} onChange={set('password')} style={{ paddingRight: '2.5rem' }} />
                <button type="button" onClick={() => setShowPw(v => !v)}
                  style={{ position: 'absolute', right: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-dim)', display: 'flex' }}>
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </Field>

            <Btn type="submit" loading={loading} style={{ width: '100%', justifyContent: 'center', marginTop: '0.5rem' }}>
              Create account
            </Btn>
          </form>

          <p style={{ textAlign: 'center', marginTop: '1.5rem', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            Already have an account?{' '}
            <Link to="/login" style={{ color: 'var(--accent)' }}>Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
