import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { accountApi } from '../../api'
import { Btn, Card, Field, SectionHeader, Modal, getErrMsg } from '../../components/ui'
import toast from 'react-hot-toast'
import { Eye, EyeOff, AlertTriangle, Shield, User } from 'lucide-react'

function Section({ title, icon: Icon, children }) {
  return (
    <Card style={{ marginBottom: '1.25rem' }}>
      <div style={{ padding: '1rem 1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
        {Icon && <Icon size={15} style={{ color: '#c8a96e' }} />}
        <h3 style={{ fontSize: '0.9rem', fontWeight: 600, fontFamily: 'inherit' }}>{title}</h3>
      </div>
      <div style={{ padding: '1.5rem' }}>{children}</div>
    </Card>
  )
}

function PwField({ label, k, form, setForm }) {
  const [show, setShow] = useState(false)
  return (
    <Field label={label}>
      <div style={{ position: 'relative' }}>
        <input type={show ? 'text' : 'password'} value={form[k] || ''}
          onChange={e => setForm(f => ({ ...f, [k]: e.target.value }))}
          style={{ paddingRight: '2.5rem' }} />
        <button type="button" onClick={() => setShow(v => !v)}
          style={{ position: 'absolute', right: '0.75rem', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-dim)', display: 'flex' }}>
          {show ? <EyeOff size={15} /> : <Eye size={15} />}
        </button>
      </div>
    </Field>
  )
}

export default function Settings() {
  const { user, logout, updateUser } = useAuth()
  const navigate = useNavigate()

  const [nameForm, setNameForm] = useState({ firstName: user?.firstName || '', lastName: user?.lastName || '' })
  const [savingName, setSavingName] = useState(false)

  const [pwForm, setPwForm]   = useState({ currentPassword: '', newPassword: '', confirmPassword: '' })
  const [savingPw, setSavingPw] = useState(false)

  const [deleteModal, setDeleteModal] = useState(false)
  const [deleteConfirm, setDeleteConfirm] = useState('')
  const [deleting, setDeleting] = useState(false)

  const handleUpdateName = async e => {
    e.preventDefault()
    if (!nameForm.firstName.trim() || !nameForm.lastName.trim()) return toast.error('Both name fields are required')
    setSavingName(true)
    try { await accountApi.updateName(nameForm); updateUser(nameForm); toast.success('Name updated') }
    catch (err) { toast.error(getErrMsg(err)) }
    finally { setSavingName(false) }
  }

  const handleChangePw = async e => {
    e.preventDefault()
    const { currentPassword, newPassword, confirmPassword } = pwForm
    if (!currentPassword || !newPassword) return toast.error('All password fields are required')
    if (newPassword !== confirmPassword) return toast.error('Passwords do not match')
    if (newPassword.length < 6) return toast.error('New password must be at least 6 characters')
    setSavingPw(true)
    try {
      await accountApi.changePassword({ currentPassword, newPassword })
      toast.success('Password updated')
      setPwForm({ currentPassword: '', newPassword: '', confirmPassword: '' })
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setSavingPw(false) }
  }

  const handleDelete = async () => {
    if (deleteConfirm !== 'DELETE') return toast.error('Type DELETE to confirm')
    setDeleting(true)
    try { await accountApi.deleteAccount(); toast.success('Account deleted'); logout(); navigate('/login') }
    catch (err) { toast.error(getErrMsg(err)); setDeleting(false) }
  }

  return (
    <div className="fade-in" style={{ maxWidth: 600 }}>
      <SectionHeader title="Account Settings" subtitle="Manage your personal info and security" />

      {/* Name */}
      <Section title="Personal Information" icon={User}>
        <form onSubmit={handleUpdateName} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <Field label="First Name" required>
              <input value={nameForm.firstName} onChange={e => setNameForm(f => ({ ...f, firstName: e.target.value }))} />
            </Field>
            <Field label="Last Name" required>
              <input value={nameForm.lastName} onChange={e => setNameForm(f => ({ ...f, lastName: e.target.value }))} />
            </Field>
          </div>
          <Field label="Email">
            <input value={user?.email || ''} disabled style={{ opacity: 0.5, cursor: 'not-allowed' }} />
          </Field>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Btn type="submit" loading={savingName}>Save name</Btn>
          </div>
        </form>
      </Section>

      {/* Password */}
      <Section title="Change Password" icon={Shield}>
        <form onSubmit={handleChangePw} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <PwField label="Current Password"  k="currentPassword"  form={pwForm} setForm={setPwForm} />
          <PwField label="New Password"       k="newPassword"       form={pwForm} setForm={setPwForm} />
          <PwField label="Confirm New Password" k="confirmPassword" form={pwForm} setForm={setPwForm} />
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Btn type="submit" loading={savingPw}>Update password</Btn>
          </div>
        </form>
      </Section>

      {/* Danger zone */}
      <div style={{ border: '1px solid rgba(224,92,92,0.3)', borderRadius: 10, overflow: 'hidden' }}>
        <div style={{ padding: '1rem 1.5rem', borderBottom: '1px solid rgba(224,92,92,0.2)', display: 'flex', alignItems: 'center', gap: '0.6rem', background: 'rgba(224,92,92,0.04)' }}>
          <AlertTriangle size={15} style={{ color: 'var(--red)' }} />
          <h3 style={{ fontSize: '0.9rem', fontWeight: 600, color: 'var(--red)', fontFamily: 'inherit' }}>Danger Zone</h3>
        </div>
        <div style={{ padding: '1.25rem 1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '1rem', flexWrap: 'wrap' }}>
          <div>
            <p style={{ fontWeight: 500, fontSize: '0.9rem' }}>Delete Account</p>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: 3 }}>
              Permanently deletes your account and all data. This cannot be undone.
            </p>
          </div>
          <Btn variant="danger" onClick={() => setDeleteModal(true)}>Delete account</Btn>
        </div>
      </div>

      {/* Delete confirmation modal */}
      <Modal open={deleteModal} onClose={() => { setDeleteModal(false); setDeleteConfirm('') }} title="Delete Account" width={440}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          <div style={{ background: 'var(--red-dim)', border: '1px solid rgba(224,92,92,0.3)', borderRadius: 8, padding: '1rem', display: 'flex', gap: '0.75rem' }}>
            <AlertTriangle size={18} style={{ color: 'var(--red)', flexShrink: 0, marginTop: 1 }} />
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: 1.65 }}>
              This will permanently delete your account, portfolio, and all blog posts. <strong>This action cannot be undone.</strong>
            </p>
          </div>
          <Field label='Type "DELETE" to confirm'>
            <input value={deleteConfirm} onChange={e => setDeleteConfirm(e.target.value)} placeholder="DELETE" />
          </Field>
          <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
            <Btn variant="ghost" onClick={() => { setDeleteModal(false); setDeleteConfirm('') }}>Cancel</Btn>
            <Btn variant="danger" onClick={handleDelete} loading={deleting} disabled={deleteConfirm !== 'DELETE'}>
              Delete permanently
            </Btn>
          </div>
        </div>
      </Modal>
    </div>
  )
}
