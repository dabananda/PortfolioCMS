import { useState, useEffect } from 'react'
import { profileApi, uploadApi } from '../../api'
import { Btn, Card, Field, SectionHeader, Spinner, getErrMsg } from '../../components/ui'
import toast from 'react-hot-toast'
import { Upload, User, Globe, EyeOff } from 'lucide-react'

const STATUS_OPTIONS = ['Available', 'Busy', 'OpenToWork', 'NotAvailable']

function Toggle({ checked, onChange, label, sub }) {
  return (
    <label style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', cursor: 'pointer', userSelect: 'none' }}>
      <div
        onClick={() => onChange(!checked)}
        style={{
          width: 42, height: 24, borderRadius: 12, flexShrink: 0,
          background: checked ? 'var(--green)' : 'var(--border)',
          position: 'relative', transition: 'background 0.22s', cursor: 'pointer',
        }}
      >
        <div style={{
          position: 'absolute', top: 3, left: checked ? 21 : 3,
          width: 18, height: 18, borderRadius: '50%', background: '#fff',
          transition: 'left 0.22s', boxShadow: '0 1px 4px rgba(0,0,0,0.35)',
        }} />
      </div>
      <div>
        <p style={{ fontSize: '0.875rem', fontWeight: 500, lineHeight: 1.3 }}>{label}</p>
        {sub && <p style={{ fontSize: '0.775rem', color: 'var(--text-muted)', marginTop: 2 }}>{sub}</p>}
      </div>
    </label>
  )
}

export default function Profile() {
  const [profile, setProfile] = useState(null)
  const [form, setForm]       = useState({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving]   = useState(false)
  const [uploading, setUploading] = useState({ image: false, resume: false })
  const [imgError, setImgError]   = useState(false)

  useEffect(() => {
    profileApi.get()
      .then(r  => { setProfile(r.data.data); setForm(r.data.data || {}) })
      .catch(() => setForm({}))
      .finally(() => setLoading(false))
  }, [])

  const set = k => e =>
    setForm(f => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }))

  const handleSave = async e => {
    e.preventDefault(); setSaving(true)
    try {
      const r = profile ? await profileApi.update(form) : await profileApi.create(form)
      setProfile(r.data.data)
      toast.success(profile ? 'Profile updated' : 'Profile created')
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setSaving(false) }
  }

  const handleUpload = async (type, file) => {
    if (!file) return
    setUploading(u => ({ ...u, [type]: true }))
    try {
      const { data } = type === 'image' ? await uploadApi.image(file) : await uploadApi.resume(file)
      const url = data.data?.url || data.data
      setForm(f => ({ ...f, [type === 'image' ? 'imageUrl' : 'resumeUrl']: url }))
      if (type === 'image') setImgError(false)
      toast.success(`${type === 'image' ? 'Photo' : 'Resume'} uploaded`)
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setUploading(u => ({ ...u, [type]: false })) }
  }

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', paddingTop: '4rem' }}>
      <Spinner size={32} />
    </div>
  )

  return (
    <div className="fade-in" style={{ maxWidth: 680 }}>
      <SectionHeader title="My Profile" subtitle="Manage your public portfolio information" />

      <form onSubmit={handleSave}>
        <Card style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.4rem' }}>

          {/* ── Avatar row ── */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
            <div style={{
              width: 72, height: 72, borderRadius: '50%', flexShrink: 0,
              background: 'var(--surface2)', border: '2px solid var(--border)',
              overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {form?.imageUrl && !imgError ? (
                <img
                  src={form.imageUrl} alt="avatar"
                  onError={() => setImgError(true)}
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
              ) : (
                <User size={28} style={{ color: 'var(--text-dim)' }} />
              )}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
              <p style={{ fontSize: '0.82rem', fontWeight: 500 }}>Profile photo</p>
              <label>
                <input type="file" accept="image/*" style={{ display: 'none' }}
                  onChange={e => handleUpload('image', e.target.files[0])} />
                <Btn type="button" variant="ghost" size="sm"
                  icon={<Upload size={13} />} loading={uploading.image}
                  onClick={e => e.currentTarget.previousSibling?.click?.()}>
                  Upload photo
                </Btn>
              </label>
            </div>
          </div>

          {/* ── Headline ── */}
          <Field label="Headline">
            <input
              value={form.headLine || ''}
              onChange={set('headLine')}
              placeholder="e.g. Full-stack Developer & Open Source Enthusiast"
            />
          </Field>

          {/* ── DOB + Location ── */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <Field label="Date of Birth">
              <input type="date" value={form.dateOfBirth?.slice(0, 10) || ''} onChange={set('dateOfBirth')} />
            </Field>
            <Field label="Location">
              <input value={form.location || ''} onChange={set('location')} placeholder="City, Country" />
            </Field>
          </div>

          {/* ── Status ── */}
          <Field label="Availability Status">
            <select value={form.status || 'Available'} onChange={set('status')}>
              {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>

          {/* ── Resume ── */}
          <div style={{
            background: 'var(--surface2)', borderRadius: 8,
            padding: '1rem 1.25rem', display: 'flex', alignItems: 'center', gap: '1rem',
          }}>
            <div style={{ flex: 1 }}>
              <p style={{ fontSize: '0.85rem', fontWeight: 500, marginBottom: 3 }}>Resume / CV</p>
              {form?.resumeUrl
                ? <a href={form.resumeUrl} target="_blank" rel="noreferrer"
                    style={{ fontSize: '0.78rem', color: '#c8a96e' }}>View current file ↗</a>
                : <p style={{ fontSize: '0.78rem', color: 'var(--text-dim)' }}>No file uploaded yet</p>}
            </div>
            <label>
              <input type="file" accept=".pdf,.doc,.docx" style={{ display: 'none' }}
                onChange={e => handleUpload('resume', e.target.files[0])} />
              <Btn type="button" variant="ghost" size="sm"
                icon={<Upload size={13} />} loading={uploading.resume}
                onClick={e => e.currentTarget.previousSibling?.click?.()}>
                Upload
              </Btn>
            </label>
          </div>

          {/* ── Public toggle ── */}
          <Toggle
            checked={!!form.isPublic}
            onChange={v => setForm(f => ({ ...f, isPublic: v }))}
            label="Make portfolio public"
            sub="Anyone can view your public portfolio page"
          />

          {/* ── Save ── */}
          <div style={{ display: 'flex', justifyContent: 'flex-end', paddingTop: '0.25rem', borderTop: '1px solid var(--border)' }}>
            <Btn type="submit" loading={saving}>{profile ? 'Save changes' : 'Create profile'}</Btn>
          </div>
        </Card>
      </form>
    </div>
  )
}
