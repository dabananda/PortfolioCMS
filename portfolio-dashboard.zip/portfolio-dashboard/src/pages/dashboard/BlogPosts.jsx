import { useState, useEffect, useCallback } from 'react'
import { blogApi, categoryApi } from '../../api'
import { Btn, Card, Modal, Field, SectionHeader, Badge, Empty, Spinner, ConfirmDialog, getErrMsg } from '../../components/ui'
import toast from 'react-hot-toast'
import { Plus, Edit2, Trash2, Eye, EyeOff, FileText, Search } from 'lucide-react'

function BlogForm({ initial, categories, onSave, onClose }) {
  const [form, setForm] = useState(initial || { title: '', summary: '', content: '', imageUrl: '', blogPostCategoryId: '' })
  const [saving, setSaving] = useState(false)
  const [imgError, setImgError] = useState(false)
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async e => {
    e.preventDefault()
    if (!form.title?.trim() || !form.content?.trim()) return toast.error('Title and content are required')
    setSaving(true)
    try { await onSave(form); onClose() }
    catch (err) { toast.error(getErrMsg(err)); setSaving(false) }
  }

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      <Field label="Title" required>
        <input value={form.title} onChange={set('title')} placeholder="Post title" />
      </Field>
      <Field label="Category">
        <select value={form.blogPostCategoryId} onChange={set('blogPostCategoryId')}>
          <option value="">— No category —</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </Field>
      <Field label="Summary">
        <textarea rows={2} value={form.summary || ''} onChange={set('summary')}
          placeholder="Short summary shown in listings…" style={{ resize: 'vertical' }} />
      </Field>
      <Field label="Content" required>
        <textarea rows={9} value={form.content} onChange={set('content')}
          placeholder="Write your content here (Markdown supported)…"
          style={{ resize: 'vertical', fontFamily: 'monospace', fontSize: '0.84rem', lineHeight: 1.6 }} />
      </Field>
      <Field label="Cover Image URL">
        <input value={form.imageUrl || ''} onChange={e => { set('imageUrl')(e); setImgError(false) }}
          placeholder="https://example.com/cover.jpg" />
        {form.imageUrl && !imgError && (
          <img src={form.imageUrl} alt="preview" onError={() => setImgError(true)}
            style={{ marginTop: 6, width: '100%', height: 120, objectFit: 'cover', borderRadius: 7, border: '1px solid var(--border)' }} />
        )}
      </Field>
      <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', paddingTop: '0.5rem' }}>
        <Btn type="button" variant="ghost" onClick={onClose}>Cancel</Btn>
        <Btn type="submit" loading={saving}>{initial ? 'Save changes' : 'Create post'}</Btn>
      </div>
    </form>
  )
}

function IconBtn({ children, onClick, hoverColor = 'var(--text)', title }) {
  return (
    <button title={title} onClick={onClick}
      style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 6, borderRadius: 6, display: 'flex', color: 'var(--text-dim)', transition: 'color 0.15s' }}
      onMouseEnter={e => e.currentTarget.style.color = hoverColor}
      onMouseLeave={e => e.currentTarget.style.color = 'var(--text-dim)'}
    >{children}</button>
  )
}

export default function BlogPosts() {
  const [posts, setPosts]         = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading]     = useState(true)
  const [search, setSearch]       = useState('')
  const [modal, setModal]         = useState(null)
  const [deleting, setDeleting]   = useState(null)
  const [actionLoading, setActionLoading] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [p, c] = await Promise.all([blogApi.getAll(), categoryApi.getAll()])
      const d = p.data.data
      setPosts(Array.isArray(d) ? d : d?.items || [])
      setCategories(c.data.data || [])
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const handleCreate = async form => {
    const { data } = await blogApi.create(form)
    setPosts(p => [data.data, ...p])
    toast.success('Post created')
  }
  const handleUpdate = async form => {
    const { data } = await blogApi.update(modal.post.id, form)
    setPosts(p => p.map(x => x.id === data.data.id ? data.data : x))
    toast.success('Post updated')
  }
  const handleToggle = async post => {
    try {
      const { data } = post.isPublished ? await blogApi.unpublish(post.id) : await blogApi.publish(post.id)
      setPosts(p => p.map(x => x.id === data.data.id ? data.data : x))
      toast.success(post.isPublished ? 'Unpublished' : 'Published ✓')
    } catch (err) { toast.error(getErrMsg(err)) }
  }
  const handleDelete = async () => {
    setActionLoading(true)
    try {
      await blogApi.delete(deleting.id)
      setPosts(p => p.filter(x => x.id !== deleting.id))
      toast.success('Deleted'); setDeleting(null)
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setActionLoading(false) }
  }

  const filtered = posts.filter(p => p.title?.toLowerCase().includes(search.toLowerCase()))

  if (loading) return <div style={{ display: 'flex', justifyContent: 'center', paddingTop: '4rem' }}><Spinner size={32} /></div>

  return (
    <div className="fade-in" style={{ maxWidth: 900 }}>
      <SectionHeader
        title="Blog Posts"
        subtitle={`${posts.length} post${posts.length !== 1 ? 's' : ''}`}
        action={<Btn icon={<Plus size={15} />} onClick={() => setModal({ type: 'create' })}>New post</Btn>}
      />

      {/* Search bar */}
      <div style={{ position: 'relative', marginBottom: '1.25rem' }}>
        <Search size={15} style={{ position: 'absolute', left: '0.8rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-dim)', pointerEvents: 'none' }} />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search posts…"
          style={{ paddingLeft: '2.3rem' }} />
      </div>

      <Card>
        {filtered.length === 0 ? (
          <Empty icon={FileText} title={search ? 'No results found' : 'No blog posts yet'}
            subtitle={!search ? 'Click "New post" to write your first article' : undefined}
            action={!search ? <Btn size="sm" icon={<Plus size={14} />} onClick={() => setModal({ type: 'create' })}>New post</Btn> : undefined}
          />
        ) : filtered.map((post, i) => (
          <div key={post.id} style={{
            display: 'flex', alignItems: 'center', gap: '0.9rem', padding: '0.9rem 1.25rem',
            borderBottom: i < filtered.length - 1 ? '1px solid var(--border)' : 'none',
          }}>
            {/* Thumbnail */}
            <div style={{ width: 44, height: 44, borderRadius: 8, background: 'var(--surface2)', flexShrink: 0, overflow: 'hidden' }}>
              {post.imageUrl && (
                <img src={post.imageUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  onError={e => e.currentTarget.style.display = 'none'} />
              )}
            </div>

            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontWeight: 500, fontSize: '0.9rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {post.title}
              </p>
              <p style={{ fontSize: '0.755rem', color: 'var(--text-muted)', marginTop: 2 }}>
                {post.blogPostCategory?.name || 'Uncategorized'}
                {post.publishedAt && ` · ${new Date(post.publishedAt).toLocaleDateString()}`}
              </p>
            </div>

            <Badge color={post.isPublished ? 'green' : 'default'}>
              {post.isPublished ? 'Published' : 'Draft'}
            </Badge>

            <div style={{ display: 'flex', gap: '0.15rem' }}>
              <IconBtn title={post.isPublished ? 'Unpublish' : 'Publish'} onClick={() => handleToggle(post)} hoverColor="var(--accent)">
                {post.isPublished ? <EyeOff size={15} /> : <Eye size={15} />}
              </IconBtn>
              <IconBtn title="Edit" onClick={() => setModal({ type: 'edit', post })}>
                <Edit2 size={15} />
              </IconBtn>
              <IconBtn title="Delete" onClick={() => setDeleting(post)} hoverColor="var(--red)">
                <Trash2 size={15} />
              </IconBtn>
            </div>
          </div>
        ))}
      </Card>

      <Modal open={!!modal} onClose={() => setModal(null)}
        title={modal?.type === 'edit' ? 'Edit Post' : 'New Blog Post'} width={660}>
        {modal && (
          <BlogForm
            initial={modal.type === 'edit' ? modal.post : null}
            categories={categories}
            onSave={modal.type === 'edit' ? handleUpdate : handleCreate}
            onClose={() => setModal(null)}
          />
        )}
      </Modal>

      <ConfirmDialog open={!!deleting} onClose={() => setDeleting(null)} onConfirm={handleDelete}
        title="Delete post" message={`Delete "${deleting?.title}"? This cannot be undone.`} loading={actionLoading} />
    </div>
  )
}
