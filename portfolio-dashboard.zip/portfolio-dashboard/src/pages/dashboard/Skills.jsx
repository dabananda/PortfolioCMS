import { skillApi } from '../../api'
import { ResourcePage } from '../../components/ResourcePage'
import { Field, Badge } from '../../components/ui'
import { Code2 } from 'lucide-react'

const PROFICIENCY = ['Beginner', 'Intermediate', 'Advanced', 'Expert']
const PROF_COLOR = { Beginner: 'default', Intermediate: 'blue', Advanced: 'accent', Expert: 'green' }
const PROF_WIDTH = { Beginner: '25%', Intermediate: '50%', Advanced: '75%', Expert: '100%' }

export default function Skills() {
  return (
    <ResourcePage
      title="Skills"
      icon={Code2}
      api={skillApi}
      emptySubtitle="Add your technical and soft skills"
      renderForm={(form, set) => (
        <>
          <Field label="Skill Name" required><input value={form.skillName || ''} onChange={set('skillName')} placeholder="e.g. React, Python, Leadership" /></Field>
          <Field label="Category" hint="e.g. Frontend, Backend, DevOps"><input value={form.category || ''} onChange={set('category')} placeholder="Category (optional)" /></Field>
          <Field label="Proficiency">
            <select value={form.proficiency || 'Intermediate'} onChange={set('proficiency')}>
              {PROFICIENCY.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </Field>
        </>
      )}
      renderRow={(item) => (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: 4 }}>
            <span style={{ fontWeight: 500, fontSize: '0.88rem' }}>{item.skillName}</span>
            {item.category && <span style={{ fontSize: '0.72rem', color: 'var(--text-dim)', background: 'var(--surface2)', padding: '1px 7px', borderRadius: 20 }}>{item.category}</span>}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div style={{ flex: 1, maxWidth: 160, height: 4, background: 'var(--border)', borderRadius: 2, overflow: 'hidden' }}>
              <div style={{ width: PROF_WIDTH[item.proficiency] || '50%', height: '100%', background: 'var(--accent)', borderRadius: 2, transition: 'width 0.4s' }} />
            </div>
            <Badge color={PROF_COLOR[item.proficiency] || 'default'}>{item.proficiency}</Badge>
          </div>
        </div>
      )}
    />
  )
}
