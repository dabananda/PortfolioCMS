import { socialApi } from '../../api'
import { ResourcePage } from '../../components/ResourcePage'
import { Field } from '../../components/ui'
import { Link2, ExternalLink } from 'lucide-react'

export default function SocialLinks() {
  return (
    <ResourcePage
      title="Social Links"
      icon={Link2}
      api={socialApi}
      emptySubtitle="Connect your social profiles"
      renderForm={(form, set) => (
        <>
          <Field label="Platform Name" required><input value={form.name || ''} onChange={set('name')} placeholder="GitHub, LinkedIn, Twitter..." /></Field>
          <Field label="URL" required><input type="url" value={form.link || ''} onChange={set('link')} placeholder="https://..." /></Field>
        </>
      )}
      renderRow={(item) => (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--accent-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)', flexShrink: 0, fontSize: '0.8rem', fontWeight: 600 }}>
            {item.name?.[0]?.toUpperCase()}
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ fontWeight: 500, fontSize: '0.88rem' }}>{item.name}</p>
            <a href={item.link} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()}
              style={{ fontSize: '0.76rem', color: 'var(--accent)', display: 'flex', alignItems: 'center', gap: 3 }}>
              {item.link.slice(0, 50)}{item.link.length > 50 ? '…' : ''} <ExternalLink size={10} />
            </a>
          </div>
        </div>
      )}
    />
  )
}
