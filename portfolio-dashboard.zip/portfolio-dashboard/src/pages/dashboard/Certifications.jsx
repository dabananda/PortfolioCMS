import { certApi } from '../../api'
import { ResourcePage } from '../../components/ResourcePage'
import { Field } from '../../components/ui'
import { Award, ExternalLink } from 'lucide-react'

export default function Certifications() {
  return (
    <ResourcePage
      title="Certifications"
      icon={Award}
      api={certApi}
      emptySubtitle="Add your certificates and credentials"
      formWidth={500}
      renderForm={(form, set) => (
        <>
          <Field label="Certification Name" required><input value={form.certificationName || ''} onChange={set('certificationName')} placeholder="AWS Certified Solutions Architect" /></Field>
          <Field label="Issuing Organization" required><input value={form.issuingOrganization || ''} onChange={set('issuingOrganization')} placeholder="Amazon Web Services" /></Field>
          <Field label="Date Obtained" required><input type="date" value={form.dateObtained || ''} onChange={set('dateObtained')} /></Field>
          <Field label="Credential ID" hint="Optional unique identifier"><input value={form.credentialId || ''} onChange={set('credentialId')} placeholder="ABC-1234-XYZ" /></Field>
          <Field label="Certificate URL"><input value={form.certificateUrl || ''} onChange={set('certificateUrl')} placeholder="https://..." /></Field>
        </>
      )}
      renderRow={(item) => (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <p style={{ fontWeight: 500, fontSize: '0.9rem' }}>{item.certificationName}</p>
            {item.certificateUrl && (
              <a href={item.certificateUrl} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()}
                style={{ color: 'var(--accent)', display: 'flex' }}><ExternalLink size={13} /></a>
            )}
          </div>
          <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: 2 }}>{item.issuingOrganization}</p>
          <div style={{ fontSize: '0.76rem', color: 'var(--text-dim)', marginTop: 3 }}>
            {item.dateObtained}
            {item.credentialId && <> · ID: {item.credentialId}</>}
          </div>
        </div>
      )}
    />
  )
}
