import { problemApi } from '../../api'
import { ResourcePage } from '../../components/ResourcePage'
import { Field } from '../../components/ui'
import { Code2, ExternalLink } from 'lucide-react'

export default function ProblemSolving() {
  return (
    <ResourcePage
      title="Problem Solving"
      icon={Code2}
      api={problemApi}
      emptySubtitle="Competitive programming profiles (Codeforces, LeetCode, etc.)"
      formWidth={480}
      renderForm={(form, set) => (
        <>
          <Field label="Judge / Platform Name" required><input value={form.judgeName || ''} onChange={set('judgeName')} placeholder="LeetCode, Codeforces, HackerRank..." /></Field>
          <Field label="Handle / Username"><input value={form.handle || ''} onChange={set('handle')} placeholder="Your username on the platform" /></Field>
          <Field label="Profile URL" required><input type="url" value={form.profileUrl || ''} onChange={set('profileUrl')} placeholder="https://leetcode.com/yourhandle" /></Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <Field label="Total Solved" required><input type="number" value={form.totalSolved ?? ''} onChange={set('totalSolved')} placeholder="350" /></Field>
            <Field label="Rank / Badge"><input value={form.rank || ''} onChange={set('rank')} placeholder="Knight, 1500, etc." /></Field>
          </div>
        </>
      )}
      renderRow={(item) => (
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{ width: 44, height: 44, borderRadius: 10, background: 'var(--blue-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--blue)', flexShrink: 0, fontWeight: 700, fontSize: '1.1rem' }}>
            {item.totalSolved}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <p style={{ fontWeight: 500, fontSize: '0.9rem' }}>{item.judgeName}</p>
              <a href={item.profileUrl} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()}
                style={{ color: 'var(--accent)', display: 'flex' }}><ExternalLink size={12} /></a>
            </div>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              {item.handle && <>@{item.handle} · </>}
              {item.rank && <>Rank: {item.rank} · </>}
              {item.totalSolved} solved
            </p>
          </div>
        </div>
      )}
    />
  )
}
