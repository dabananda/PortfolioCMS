import { projectApi } from '../../api'
import { ResourcePage } from '../../components/ResourcePage'
import { Field, Badge } from '../../components/ui'
import { Briefcase, GitBranch, ExternalLink } from 'lucide-react'

export default function Projects() {
  return (
    <ResourcePage
      title="Projects"
      icon={Briefcase}
      api={projectApi}
      emptySubtitle="Showcase your best work"
      formWidth={560}
      renderForm={(form, set, setVal) => (
        <>
          <Field label="Title" required>
            <input value={form.title || ''} onChange={set('title')} placeholder="Project name" />
          </Field>
          <Field label="Description" required>
            <textarea rows={3} value={form.description || ''} onChange={set('description')}
              placeholder="What does this project do?" style={{ resize: 'vertical' }} />
          </Field>
          <Field label="Technologies" hint="Comma-separated: React, Node.js, PostgreSQL">
            <input
              value={Array.isArray(form.technologies) ? form.technologies.join(', ') : (form.technologies || '')}
              onChange={e => setVal('technologies')(e.target.value.split(',').map(t => t.trim()).filter(Boolean))}
              placeholder="React, TypeScript, Tailwind…"
            />
          </Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <Field label="GitHub URL">
              <input value={form.gitHubUrl || ''} onChange={set('gitHubUrl')} placeholder="https://github.com/…" />
            </Field>
            <Field label="Live URL">
              <input value={form.liveUrl || ''} onChange={set('liveUrl')} placeholder="https://…" />
            </Field>
          </div>
          <Field label="Cover Image URL">
            <input value={form.imageUrl || ''} onChange={set('imageUrl')} placeholder="https://…" />
            {form.imageUrl && (
              <img src={form.imageUrl} alt="preview" onError={e => e.currentTarget.style.display = 'none'}
                style={{ marginTop: 6, width: '100%', height: 100, objectFit: 'cover', borderRadius: 7, border: '1px solid var(--border)' }} />
            )}
          </Field>
        </>
      )}
      renderRow={item => (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: 4 }}>
            {item.imageUrl && (
              <img src={item.imageUrl} alt="" onError={e => e.currentTarget.style.display = 'none'}
                style={{ width: 38, height: 38, borderRadius: 7, objectFit: 'cover', flexShrink: 0 }} />
            )}
            <div>
              <p style={{ fontWeight: 500, fontSize: '0.9rem' }}>{item.title}</p>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: 1 }}>
                {item.description?.slice(0, 80)}{item.description?.length > 80 ? '…' : ''}
              </p>
            </div>
          </div>
          {item.technologies?.length > 0 && (
            <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap', marginTop: 6 }}>
              {item.technologies.slice(0, 6).map(t => (
                <span key={t} style={{ fontSize: '0.7rem', padding: '1px 7px', borderRadius: 20, background: 'var(--surface2)', color: 'var(--text-muted)' }}>{t}</span>
              ))}
            </div>
          )}
          <div style={{ display: 'flex', gap: '1rem', marginTop: 7 }}>
            {item.gitHubUrl && (
              <a href={item.gitHubUrl} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()}
                style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 3 }}>
                <GitBranch size={12} /> GitHub
              </a>
            )}
            {item.liveUrl && (
              <a href={item.liveUrl} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()}
                style={{ fontSize: '0.75rem', color: '#c8a96e', display: 'flex', alignItems: 'center', gap: 3 }}>
                <ExternalLink size={12} /> Live
              </a>
            )}
          </div>
        </div>
      )}
    />
  )
}
