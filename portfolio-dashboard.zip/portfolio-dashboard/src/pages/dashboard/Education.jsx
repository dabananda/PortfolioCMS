import { educationApi } from '../../api'
import { ResourcePage } from '../../components/ResourcePage'
import { Field } from '../../components/ui'
import { GraduationCap } from 'lucide-react'

export default function Education() {
  return (
    <ResourcePage
      title="Education"
      icon={GraduationCap}
      api={educationApi}
      emptySubtitle="Add your academic background"
      renderForm={(form, set) => (
        <>
          <Field label="Institute Name" required><input value={form.instituteName || ''} onChange={set('instituteName')} placeholder="University / College name" /></Field>
          <Field label="Department" required><input value={form.department || ''} onChange={set('department')} placeholder="Computer Science & Engineering" /></Field>
          <Field label="Institute Location"><input value={form.instituteLocation || ''} onChange={set('instituteLocation')} placeholder="City, Country" /></Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <Field label="CGPA / Grade"><input type="number" step="0.01" value={form.cgpa ?? ''} onChange={set('cgpa')} placeholder="3.80" /></Field>
            <Field label="Scale (e.g. 4.0)"><input type="number" step="0.01" value={form.scale ?? ''} onChange={set('scale')} placeholder="4.0" /></Field>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <Field label="Start Date" required><input type="date" value={form.startDate || ''} onChange={set('startDate')} /></Field>
            <Field label="End Date" hint="Leave blank if ongoing"><input type="date" value={form.endDate || ''} onChange={set('endDate')} /></Field>
          </div>
        </>
      )}
      renderRow={(item) => (
        <div>
          <p style={{ fontWeight: 500, fontSize: '0.9rem' }}>{item.instituteName}</p>
          <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: 2 }}>{item.department}</p>
          <div style={{ display: 'flex', gap: '1rem', marginTop: 4, fontSize: '0.76rem', color: 'var(--text-dim)' }}>
            <span>CGPA: {item.cgpa}/{item.scale}</span>
            <span>{item.startDate} — {item.endDate || 'Present'}</span>
            {item.instituteLocation && <span>{item.instituteLocation}</span>}
          </div>
        </div>
      )}
    />
  )
}
