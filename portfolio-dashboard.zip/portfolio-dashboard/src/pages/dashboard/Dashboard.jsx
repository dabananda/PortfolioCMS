import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { blogApi, skillApi, projectApi, contactApi, profileApi } from '../../api'
import { Card, Badge, Spinner } from '../../components/ui'
import { FileText, Code2, Briefcase, MessageSquare, ArrowRight, User } from 'lucide-react'

function StatCard({ icon: Icon, label, value, to, bg, iconColor }) {
  return (
    <Link to={to} style={{ textDecoration: 'none', display: 'block' }}>
      <div
        style={{
          background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 10, padding: '1.25rem',
          display: 'flex', alignItems: 'center', gap: '1rem',
          transition: 'border-color 0.18s, transform 0.18s',
          cursor: 'pointer',
        }}
        onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--border-hover)'; e.currentTarget.style.transform = 'translateY(-1px)' }}
        onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = 'none' }}
      >
        <div style={{
          width: 46, height: 46, borderRadius: 11,
          background: bg, display: 'flex', alignItems: 'center',
          justifyContent: 'center', flexShrink: 0,
        }}>
          <Icon size={20} style={{ color: iconColor }} />
        </div>
        <div style={{ flex: 1 }}>
          <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: 3 }}>{label}</p>
          <p style={{ fontSize: '1.55rem', fontFamily: "'DM Serif Display', serif", lineHeight: 1 }}>
            {value ?? '—'}
          </p>
        </div>
        <ArrowRight size={15} style={{ color: 'var(--text-dim)' }} />
      </div>
    </Link>
  )
}

export default function Dashboard() {
  const { user } = useAuth()
  const [stats, setStats]         = useState({})
  const [recentBlogs, setRecent]  = useState([])
  const [unread, setUnread]       = useState(0)
  const [profile, setProfile]     = useState(null)
  const [loading, setLoading]     = useState(true)

  useEffect(() => {
    Promise.allSettled([
      blogApi.getAll({ pageSize: 5 }),
      skillApi.getAll(),
      projectApi.getAll(),
      contactApi.getAll({ pageSize: 100 }),
      profileApi.get(),
    ]).then(([blogs, skills, projects, msgs, prof]) => {
      if (blogs.status === 'fulfilled') {
        const d = blogs.value.data.data
        const list = Array.isArray(d) ? d : d?.items || []
        setRecent(list.slice(0, 4))
        setStats(s => ({ ...s, blogs: list.length }))
      }
      if (skills.status === 'fulfilled') {
        const d = skills.value.data.data
        setStats(s => ({ ...s, skills: Array.isArray(d) ? d.length : 0 }))
      }
      if (projects.status === 'fulfilled') {
        const d = projects.value.data.data
        setStats(s => ({ ...s, projects: Array.isArray(d) ? d.length : 0 }))
      }
      if (msgs.status === 'fulfilled') {
        const d = msgs.value.data.data
        const list = Array.isArray(d) ? d : d?.items || []
        const unreadCount = list.filter(m => !m.isRead).length
        setUnread(unreadCount)
        setStats(s => ({ ...s, messages: list.length }))
      }
      if (prof.status === 'fulfilled') setProfile(prof.value.data.data)
    }).finally(() => setLoading(false))
  }, [])

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', paddingTop: '5rem' }}>
      <Spinner size={32} />
    </div>
  )

  return (
    <div className="fade-in" style={{ maxWidth: 900 }}>

      {/* Header */}
      <div style={{ marginBottom: '2.5rem' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', marginBottom: '0.3rem' }}>{greeting},</p>
        <h1 style={{ fontSize: '2rem', marginBottom: '0.6rem' }}>{user?.firstName} {user?.lastName}</h1>
        {profile && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
            <Badge color={profile.isPublic ? 'green' : 'default'}>
              {profile.isPublic ? '● Portfolio public' : '○ Portfolio private'}
            </Badge>
            {profile.headLine && (
              <span style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>{profile.headLine}</span>
            )}
          </div>
        )}
      </div>

      {/* Stats grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
        <StatCard icon={FileText}      label="Blog Posts" value={stats.blogs}    to="/dashboard/blog"      bg="var(--accent-dim)"  iconColor="#c8a96e" />
        <StatCard icon={Code2}         label="Skills"     value={stats.skills}   to="/dashboard/skills"    bg="var(--blue-dim)"    iconColor="var(--blue)" />
        <StatCard icon={Briefcase}     label="Projects"   value={stats.projects} to="/dashboard/projects"  bg="var(--green-dim)"   iconColor="var(--green)" />
        <StatCard icon={MessageSquare} label="Messages"   value={stats.messages} to="/dashboard/messages"  bg={unread ? 'var(--red-dim)' : 'var(--surface2)'} iconColor={unread ? 'var(--red)' : 'var(--text-muted)'} />
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>

        {/* Recent blog posts */}
        <Card>
          <div style={{ padding: '1.1rem 1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600 }}>Recent Blog Posts</h3>
            <Link to="/dashboard/blog" style={{ fontSize: '0.8rem', color: '#c8a96e', display: 'flex', alignItems: 'center', gap: 4 }}>
              View all <ArrowRight size={13} />
            </Link>
          </div>
          {recentBlogs.length === 0 ? (
            <p style={{ padding: '1.5rem', color: 'var(--text-dim)', textAlign: 'center', fontSize: '0.875rem' }}>
              No blog posts yet
            </p>
          ) : recentBlogs.map((post, i) => (
            <div key={post.id} style={{
              display: 'flex', alignItems: 'center', gap: '1rem', padding: '0.85rem 1.5rem',
              borderBottom: i < recentBlogs.length - 1 ? '1px solid var(--border)' : 'none',
            }}>
              {/* Thumbnail */}
              <div style={{ width: 40, height: 40, borderRadius: 8, background: 'var(--surface2)', flexShrink: 0, overflow: 'hidden' }}>
                {post.imageUrl && (
                  <img src={post.imageUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    onError={e => e.currentTarget.style.display = 'none'} />
                )}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontWeight: 500, fontSize: '0.875rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {post.title}
                </p>
                <p style={{ fontSize: '0.755rem', color: 'var(--text-muted)', marginTop: 1 }}>
                  {post.blogPostCategory?.name || 'Uncategorized'}
                </p>
              </div>
              <Badge color={post.isPublished ? 'green' : 'default'}>
                {post.isPublished ? 'Published' : 'Draft'}
              </Badge>
            </div>
          ))}
        </Card>

        {/* Nudge: create profile */}
        {!profile && (
          <div style={{
            background: 'rgba(200,169,110,0.06)', border: '1px solid rgba(200,169,110,0.22)',
            borderRadius: 10, padding: '1.25rem 1.5rem',
            display: 'flex', alignItems: 'center', gap: '1rem',
          }}>
            <User size={22} style={{ color: '#c8a96e', flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <p style={{ fontWeight: 500, fontSize: '0.9rem' }}>Complete your profile</p>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: 2 }}>
                Set up your public portfolio to get discovered.
              </p>
            </div>
            <Link to="/dashboard/profile">
              <button style={{
                background: '#c8a96e', color: '#0c0c0f', border: 'none', borderRadius: 7,
                padding: '0.4rem 1rem', fontSize: '0.82rem', fontWeight: 600, cursor: 'pointer',
              }}>Set up →</button>
            </Link>
          </div>
        )}

        {/* Nudge: unread messages */}
        {unread > 0 && (
          <div style={{
            background: 'var(--red-dim)', border: '1px solid rgba(224,92,92,0.3)',
            borderRadius: 10, padding: '1.1rem 1.5rem',
            display: 'flex', alignItems: 'center', gap: '1rem',
          }}>
            <MessageSquare size={20} style={{ color: 'var(--red)', flexShrink: 0 }} />
            <p style={{ flex: 1, fontSize: '0.875rem', fontWeight: 500 }}>
              You have {unread} unread message{unread > 1 ? 's' : ''}
            </p>
            <Link to="/dashboard/messages">
              <button style={{
                background: 'var(--red)', color: '#fff', border: 'none', borderRadius: 7,
                padding: '0.4rem 1rem', fontSize: '0.82rem', fontWeight: 600, cursor: 'pointer',
              }}>View →</button>
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
