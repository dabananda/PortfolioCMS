import { reviewApi } from '../../api'
import { ResourcePage } from '../../components/ResourcePage'
import { Field } from '../../components/ui'
import { Star } from 'lucide-react'

function StarDisplay({ rating }) {
  return (
    <div style={{ display: 'flex', gap: 2 }}>
      {[1,2,3,4,5].map(i => (
        <Star key={i} size={13} style={{ color: i <= rating ? 'var(--accent)' : 'var(--border)', fill: i <= rating ? 'var(--accent)' : 'none' }} />
      ))}
    </div>
  )
}

export default function Reviews() {
  return (
    <ResourcePage
      title="Reviews"
      icon={Star}
      api={reviewApi}
      emptySubtitle="Add testimonials from clients or colleagues"
      formWidth={500}
      renderForm={(form, set, setVal) => (
        <>
          <Field label="Reviewer Name" required><input value={form.name || ''} onChange={set('name')} placeholder="John Smith" /></Field>
          <Field label="Designation / Title"><input value={form.designation || ''} onChange={set('designation')} placeholder="CTO at Acme Corp" /></Field>
          <Field label="Rating (1–5)" required>
            <div style={{ display: 'flex', gap: '0.5rem', padding: '0.4rem 0' }}>
              {[1,2,3,4,5].map(n => (
                <button key={n} type="button" onClick={() => setVal('rating')(n)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 2 }}>
                  <Star size={22} style={{ color: n <= (form.rating || 0) ? 'var(--accent)' : 'var(--border)', fill: n <= (form.rating || 0) ? 'var(--accent)' : 'none', transition: 'color 0.15s' }} />
                </button>
              ))}
            </div>
          </Field>
          <Field label="Comment" required>
            <textarea rows={4} value={form.comment || ''} onChange={set('comment')} placeholder="What did they say about your work?" style={{ resize: 'vertical' }} />
          </Field>
        </>
      )}
      renderRow={(item) => (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: 4 }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--accent-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)', fontSize: '0.8rem', fontWeight: 600, flexShrink: 0 }}>
              {item.name?.[0]}
            </div>
            <div>
              <p style={{ fontWeight: 500, fontSize: '0.88rem' }}>{item.name}</p>
              {item.designation && <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{item.designation}</p>}
            </div>
            <div style={{ marginLeft: 'auto' }}><StarDisplay rating={item.rating} /></div>
          </div>
          <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.6, fontStyle: 'italic' }}>"{item.comment}"</p>
        </div>
      )}
    />
  )
}
