import { workApi } from '../../api'
import { ResourcePage } from '../../components/ResourcePage'
import { Field } from '../../components/ui'
import { Briefcase } from 'lucide-react'

export default function WorkExperience() {
  return (
    <ResourcePage
      title="Work Experience"
      icon={Briefcase}
      api={workApi}
      emptySubtitle="Add your professional experience"
      formWidth={540}
      renderForm={(form, set) => (
        <>
          <Field label="Company Name" required><input value={form.companyName || ''} onChange={set('companyName')} placeholder="Company Inc." /></Field>
          <Field label="Your Role" required><input value={form.role || ''} onChange={set('role')} placeholder="Senior Software Engineer" /></Field>
          <Field label="Company Description">
            <textarea rows={2} value={form.companyDescription || ''} onChange={set('companyDescription')} placeholder="What does the company do?" style={{ resize: 'vertical' }} />
          </Field>
          <Field label="Work Description">
            <textarea rows={3} value={form.workDescription || ''} onChange={set('workDescription')} placeholder="Describe your responsibilities and achievements..." style={{ resize: 'vertical' }} />
          </Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <Field label="Start Date" required><input type="date" value={form.startDate || ''} onChange={set('startDate')} /></Field>
            <Field label="End Date" hint="Leave blank if current"><input type="date" value={form.endDate || ''} onChange={set('endDate')} /></Field>
          </div>
        </>
      )}
      renderRow={(item) => (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: 2 }}>
            <p style={{ fontWeight: 500, fontSize: '0.9rem' }}>{item.role}</p>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>@</span>
            <p style={{ fontSize: '0.88rem', color: 'var(--accent)' }}>{item.companyName}</p>
          </div>
          <p style={{ fontSize: '0.76rem', color: 'var(--text-dim)' }}>
            {item.startDate} — {item.endDate || 'Present'}
          </p>
          {item.workDescription && <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: 5, lineHeight: 1.5 }}>{item.workDescription.slice(0, 120)}{item.workDescription.length > 120 ? '…' : ''}</p>}
        </div>
      )}
    />
  )
}
