import { useState, useEffect, useCallback } from 'react'
import { contactApi } from '../../api'
import { Btn, Card, Modal, SectionHeader, Badge, Empty, Spinner, ConfirmDialog, getErrMsg } from '../../components/ui'
import toast from 'react-hot-toast'
import { MessageSquare, Trash2, MailOpen, Mail } from 'lucide-react'

function fmtDate(s) {
  if (!s) return ''
  try { return new Date(s).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) }
  catch { return '' }
}
function fmtDateTime(s) {
  if (!s) return ''
  try { return new Date(s).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) }
  catch { return '' }
}

function TabBtn({ active, onClick, children }) {
  return (
    <button onClick={onClick} style={{
      padding: '0.3rem 0.9rem', borderRadius: 6, fontSize: '0.82rem', fontWeight: 500,
      background: active ? 'var(--surface2)' : 'transparent',
      color: active ? 'var(--text)' : 'var(--text-muted)',
      border: active ? '1px solid var(--border)' : '1px solid transparent',
      cursor: 'pointer', transition: 'all 0.15s',
    }}>{children}</button>
  )
}

export default function Messages() {
  const [messages, setMessages] = useState([])
  const [loading, setLoading]   = useState(true)
  const [selected, setSelected] = useState(null)
  const [deleting, setDeleting] = useState(null)
  const [actionLoading, setActionLoading] = useState(false)
  const [filter, setFilter]     = useState('all')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await contactApi.getAll()
      const d = data.data
      setMessages(Array.isArray(d) ? d : d?.items || [])
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const markRead = async msg => {
    if (msg.isRead) return
    try {
      const { data } = await contactApi.markAsRead(msg.id)
      setMessages(p => p.map(x => x.id === msg.id ? { ...x, ...data.data } : x))
    } catch { /* silent */ }
  }

  const handleOpen = msg => { setSelected(msg); markRead(msg) }

  const handleDelete = async () => {
    setActionLoading(true)
    try {
      await contactApi.delete(deleting.id)
      setMessages(p => p.filter(x => x.id !== deleting.id))
      if (selected?.id === deleting.id) setSelected(null)
      toast.success('Deleted'); setDeleting(null)
    } catch (err) { toast.error(getErrMsg(err)) }
    finally { setActionLoading(false) }
  }

  const filtered = messages.filter(m =>
    filter === 'all' ? true : filter === 'unread' ? !m.isRead : m.isRead
  )
  const unreadCount = messages.filter(m => !m.isRead).length

  if (loading) return <div style={{ display: 'flex', justifyContent: 'center', paddingTop: '4rem' }}><Spinner size={32} /></div>

  return (
    <div className="fade-in" style={{ maxWidth: 860 }}>
      <SectionHeader
        title="Messages"
        subtitle={unreadCount > 0 ? `${unreadCount} unread` : `${messages.length} total`}
      />

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: '0.2rem', marginBottom: '1.25rem', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: 4, width: 'fit-content' }}>
        <TabBtn active={filter === 'all'}    onClick={() => setFilter('all')}>All</TabBtn>
        <TabBtn active={filter === 'unread'} onClick={() => setFilter('unread')}>
          Unread {unreadCount > 0 && <span style={{ marginLeft: 4, background: 'var(--red)', color: '#fff', borderRadius: 20, padding: '0 5px', fontSize: '0.68rem' }}>{unreadCount}</span>}
        </TabBtn>
        <TabBtn active={filter === 'read'}   onClick={() => setFilter('read')}>Read</TabBtn>
      </div>

      <Card>
        {filtered.length === 0 ? (
          <Empty icon={MessageSquare} title="No messages" subtitle="Contact form messages will appear here" />
        ) : filtered.map((msg, i) => (
          <div key={msg.id} onClick={() => handleOpen(msg)}
            style={{
              display: 'flex', alignItems: 'flex-start', gap: '0.85rem',
              padding: '1rem 1.25rem',
              borderBottom: i < filtered.length - 1 ? '1px solid var(--border)' : 'none',
              cursor: 'pointer',
              background: !msg.isRead ? 'rgba(200,169,110,0.04)' : 'transparent',
              transition: 'background 0.15s',
            }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--surface2)'}
            onMouseLeave={e => e.currentTarget.style.background = !msg.isRead ? 'rgba(200,169,110,0.04)' : 'transparent'}
          >
            {/* Icon */}
            <div style={{ paddingTop: 2, color: !msg.isRead ? '#c8a96e' : 'var(--text-dim)', flexShrink: 0 }}>
              {msg.isRead ? <MailOpen size={16} /> : <Mail size={16} />}
            </div>

            {/* Content */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: 2, flexWrap: 'wrap' }}>
                <span style={{ fontWeight: !msg.isRead ? 600 : 400, fontSize: '0.875rem' }}>
                  {msg.fullName}
                </span>
                {!msg.isRead && <Badge color="accent">New</Badge>}
                <span style={{ marginLeft: 'auto', fontSize: '0.72rem', color: 'var(--text-dim)', flexShrink: 0 }}>
                  {fmtDate(msg.createdAt)}
                </span>
              </div>
              <p style={{ fontSize: '0.82rem', fontWeight: 500, color: 'var(--text-muted)', marginBottom: 2 }}>
                {msg.subject}
              </p>
              <p style={{ fontSize: '0.775rem', color: 'var(--text-dim)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {msg.description}
              </p>
            </div>

            {/* Delete button */}
            <button onClick={e => { e.stopPropagation(); setDeleting(msg) }}
              style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 6, borderRadius: 6, color: 'var(--text-dim)', display: 'flex', flexShrink: 0, transition: 'color 0.15s' }}
              onMouseEnter={e => e.currentTarget.style.color = 'var(--red)'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--text-dim)'}
            ><Trash2 size={14} /></button>
          </div>
        ))}
      </Card>

      {/* Detail modal */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title={selected?.subject || 'Message'} width={560}>
        {selected && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            <div style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap' }}>
              <div>
                <p style={{ fontSize: '0.7rem', color: 'var(--text-dim)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 4 }}>From</p>
                <p style={{ fontSize: '0.875rem', fontWeight: 500 }}>{selected.fullName}</p>
                <a href={`mailto:${selected.email}`} style={{ fontSize: '0.8rem', color: '#c8a96e' }}>{selected.email}</a>
              </div>
              <div>
                <p style={{ fontSize: '0.7rem', color: 'var(--text-dim)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 4 }}>Received</p>
                <p style={{ fontSize: '0.85rem' }}>{fmtDateTime(selected.createdAt) || '—'}</p>
              </div>
            </div>

            <div style={{ background: 'var(--surface2)', borderRadius: 8, padding: '1rem 1.25rem', fontSize: '0.9rem', lineHeight: 1.75, color: 'var(--text-muted)', whiteSpace: 'pre-wrap', minHeight: 80 }}>
              {selected.description}
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
              <Btn variant="danger" size="sm" onClick={() => { setDeleting(selected); setSelected(null) }}>Delete</Btn>
              <a href={`mailto:${selected.email}?subject=Re: ${encodeURIComponent(selected.subject || '')}`}>
                <Btn size="sm">Reply via email</Btn>
              </a>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog open={!!deleting} onClose={() => setDeleting(null)} onConfirm={handleDelete}
        title="Delete message" message="Remove this message permanently?" loading={actionLoading} />
    </div>
  )
}
