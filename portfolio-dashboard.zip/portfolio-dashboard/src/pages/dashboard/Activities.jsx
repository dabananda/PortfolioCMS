import { activityApi } from '../../api'
import { ResourcePage } from '../../components/ResourcePage'
import { Field } from '../../components/ui'
import { Activity } from 'lucide-react'

export default function Activities() {
  return (
    <ResourcePage
      title="Extra Curricular Activities"
      icon={Activity}
      api={activityApi}
      emptySubtitle="Clubs, volunteering, competitions, etc."
      formWidth={520}
      renderForm={(form, set) => (
        <>
          <Field label="Title" required><input value={form.title || ''} onChange={set('title')} placeholder="Club President, Hackathon Participant..." /></Field>
          <Field label="Organization" required><input value={form.organization || ''} onChange={set('organization')} placeholder="Organization / Institution" /></Field>
          <Field label="Description" required>
            <textarea rows={3} value={form.description || ''} onChange={set('description')} placeholder="Describe your role and contributions..." style={{ resize: 'vertical' }} />
          </Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <Field label="Start Date" required><input type="date" value={form.startDate || ''} onChange={set('startDate')} /></Field>
            <Field label="End Date" hint="Leave blank if ongoing"><input type="date" value={form.endDate || ''} onChange={set('endDate')} /></Field>
          </div>
        </>
      )}
      renderRow={(item) => (
        <div>
          <p style={{ fontWeight: 500, fontSize: '0.9rem' }}>{item.title}</p>
          <p style={{ fontSize: '0.82rem', color: 'var(--accent)', marginTop: 1 }}>{item.organization}</p>
          <p style={{ fontSize: '0.76rem', color: 'var(--text-dim)', marginTop: 2 }}>{item.startDate} — {item.endDate || 'Present'}</p>
          {item.description && <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: 5 }}>{item.description.slice(0, 100)}{item.description.length > 100 ? '…' : ''}</p>}
        </div>
      )}
    />
  )
}
