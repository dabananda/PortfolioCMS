import { categoryApi } from '../../api'
import { ResourcePage } from '../../components/ResourcePage'
import { Field } from '../../components/ui'
import { Tag } from 'lucide-react'

export default function Categories() {
  return (
    <ResourcePage
      title="Blog Categories"
      icon={Tag}
      api={categoryApi}
      emptySubtitle="Organize your blog posts with categories"
      renderForm={(form, set) => (
        <>
          <Field label="Category Name" required><input value={form.name || ''} onChange={set('name')} placeholder="Technology, Travel, Design..." /></Field>
          <Field label="Description"><textarea rows={2} value={form.description || ''} onChange={set('description')} placeholder="Brief description (optional)" style={{ resize: 'vertical' }} /></Field>
        </>
      )}
      renderRow={(item) => (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{ width: 34, height: 34, borderRadius: 8, background: 'var(--accent-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Tag size={15} style={{ color: 'var(--accent)' }} />
          </div>
          <div>
            <p style={{ fontWeight: 500, fontSize: '0.88rem' }}>{item.name}</p>
            {item.description && <p style={{ fontSize: '0.76rem', color: 'var(--text-muted)' }}>{item.description}</p>}
            <p style={{ fontSize: '0.72rem', color: 'var(--text-dim)', marginTop: 2 }}>{item.blogPosts?.length ?? 0} posts</p>
          </div>
        </div>
      )}
    />
  )
}
