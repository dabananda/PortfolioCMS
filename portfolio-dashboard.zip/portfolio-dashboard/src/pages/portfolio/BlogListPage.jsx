import { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { portfolioApi } from '../../api'
import { PORTFOLIO_USERNAME } from '../../config'
import { Spinner } from '../../components/ui'
import { ArrowLeft, Search, Calendar, Tag } from 'lucide-react'

const fmtDate = d => {
  if (!d) return ''
  try { return new Date(d).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) }
  catch { return '' }
}

export default function BlogListPage() {
  const [posts, setPosts]     = useState([])
  const [total, setTotal]     = useState(0)
  const [totalPages, setTP]   = useState(1)
  const [page, setPage]       = useState(1)
  const [search, setSearch]   = useState('')
  const [query, setQuery]     = useState('')
  const [loading, setLoading] = useState(true)
  const [profile, setProfile] = useState(null)

  useEffect(() => {
    portfolioApi.get(PORTFOLIO_USERNAME)
      .then(r => setProfile(r.data.data?.profile))
      .catch(() => {})
  }, [])

  const load = useCallback(async () => {
    if (!PORTFOLIO_USERNAME) return
    setLoading(true)
    try {
      const { data } = await portfolioApi.getBlog(PORTFOLIO_USERNAME, {
        page, pageSize: 9, search: query || undefined,
      })
      const d = data.data
      setPosts(Array.isArray(d) ? d : d?.items || [])
      setTotal(d?.totalCount ?? 0)
      setTP(d?.totalPages ?? 1)
    } catch {}
    finally { setLoading(false) }
  }, [page, query])

  useEffect(() => { load() }, [load])

  const handleSearch = e => { e.preventDefault(); setPage(1); setQuery(search) }

  const inputSt = {
    background: 'var(--pf-card)', border: '1px solid var(--pf-border)',
    color: 'var(--pf-text)', borderRadius: 8,
    padding: '0.65rem 0.9rem 0.65rem 2.4rem',
    width: '100%', fontFamily: 'inherit', fontSize: '0.875rem',
    outline: 'none', transition: 'border-color 0.2s',
  }

  return (
    <div className="pf-root" style={{ minHeight: '100vh' }}>

      {/* Top bar */}
      <header style={{ position: 'sticky', top: 0, zIndex: 50, background: 'rgba(8,8,11,0.93)', backdropFilter: 'blur(14px)', borderBottom: '1px solid var(--pf-border)' }}>
        <div style={{ maxWidth: 1100, margin: '0 auto', padding: '0 1.5rem', height: 60, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--pf-muted)', fontSize: '0.85rem', textDecoration: 'none', transition: 'color 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--pf-accent)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--pf-muted)'}>
            <ArrowLeft size={15} />
            {profile ? `${profile.firstName} ${profile.lastName}` : 'Portfolio'}
          </Link>
          <span style={{ fontFamily: "'DM Serif Display', serif", fontSize: '1.05rem', color: 'var(--pf-accent)' }}>Blog</span>
        </div>
      </header>

      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '4rem 1.5rem 6rem' }}>

        {/* Page header */}
        <div style={{ marginBottom: '3rem' }}>
          <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 'clamp(2rem, 5vw, 3rem)', fontWeight: 400, letterSpacing: '-0.02em', marginBottom: '0.5rem' }}>
            {profile ? `${profile.firstName}'s ` : ''}<span style={{ color: 'var(--pf-accent)' }}>Articles</span>
          </h1>
          <p style={{ color: 'var(--pf-muted)', fontSize: '0.9rem' }}>{total} article{total !== 1 ? 's' : ''} published</p>
        </div>

        {/* Search bar */}
        <form onSubmit={handleSearch} style={{ display: 'flex', gap: '0.75rem', marginBottom: '3rem', maxWidth: 480 }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <Search size={15} style={{ position: 'absolute', left: '0.85rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--pf-dim)', pointerEvents: 'none' }} />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search articles…"
              style={inputSt}
              onFocus={e => e.currentTarget.style.borderColor = 'var(--pf-accent)'}
              onBlur={e => e.currentTarget.style.borderColor = 'var(--pf-border)'}
            />
          </div>
          <button type="submit"
            style={{ padding: '0.65rem 1.25rem', background: 'var(--pf-accent)', color: '#0c0c0f', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: '0.875rem', cursor: 'pointer', fontFamily: 'inherit', whiteSpace: 'nowrap', transition: 'background 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--pf-accent2)'}
            onMouseLeave={e => e.currentTarget.style.background = 'var(--pf-accent)'}>
            Search
          </button>
        </form>

        {/* Grid */}
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '5rem' }}>
            <Spinner size={32} />
          </div>
        ) : posts.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '5rem 2rem', color: 'var(--pf-muted)' }}>
            <p style={{ fontSize: '3rem', marginBottom: '1rem' }}>📭</p>
            <p style={{ fontSize: '1rem' }}>{query ? `No articles matching "${query}"` : 'No articles published yet.'}</p>
            {query && (
              <button onClick={() => { setSearch(''); setQuery(''); setPage(1) }}
                style={{ marginTop: '1rem', background: 'none', border: 'none', color: 'var(--pf-accent)', cursor: 'pointer', fontSize: '0.875rem', fontFamily: 'inherit' }}>
                Clear search
              </button>
            )}
          </div>
        ) : (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.5rem', marginBottom: '3.5rem' }}>
              {posts.map(p => (
                <Link key={p.id} to={`/blog/${p.slug}`} style={{ textDecoration: 'none' }}>
                  <article className="pf-card" style={{ overflow: 'hidden', height: '100%', display: 'flex', flexDirection: 'column' }}>
                    {/* Cover */}
                    {p.imageUrl && (
                      <div style={{ height: 190, overflow: 'hidden', flexShrink: 0 }}>
                        <img
                          src={p.imageUrl} alt={p.title}
                          onError={e => e.currentTarget.parentElement.style.display = 'none'}
                          style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.38s' }}
                          onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.05)'}
                          onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'} />
                      </div>
                    )}

                    <div style={{ padding: '1.4rem', flex: 1, display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                      {p.categoryName && (
                        <span className="pf-tag" style={{ display: 'inline-flex', alignItems: 'center', gap: 4, width: 'fit-content' }}>
                          <Tag size={9} /> {p.categoryName}
                        </span>
                      )}
                      <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: '1.15rem', fontWeight: 400, lineHeight: 1.35, color: 'var(--pf-text)' }}>
                        {p.title}
                      </h2>
                      {p.summary && (
                        <p style={{ fontSize: '0.855rem', color: 'var(--pf-muted)', lineHeight: 1.68, flex: 1 }}>
                          {p.summary.slice(0, 120)}{p.summary.length > 120 ? '…' : ''}
                        </p>
                      )}
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: '0.755rem', color: 'var(--pf-dim)', marginTop: 4 }}>
                        <Calendar size={11} /> {fmtDate(p.publishedAt)}
                      </div>
                    </div>
                  </article>
                </Link>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '0.4rem' }}>
                <PgBtn onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>← Prev</PgBtn>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(n => (
                  <PgBtn key={n} onClick={() => setPage(n)} active={page === n}>{n}</PgBtn>
                ))}
                <PgBtn onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}>Next →</PgBtn>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

function PgBtn({ children, onClick, disabled, active }) {
  return (
    <button onClick={onClick} disabled={disabled}
      style={{
        padding: '0.45rem 0.8rem', borderRadius: 7, fontFamily: 'inherit',
        fontSize: '0.85rem', cursor: disabled ? 'not-allowed' : 'pointer',
        background: active ? 'var(--pf-accent)' : 'var(--pf-card)',
        color: active ? '#0c0c0f' : disabled ? 'var(--pf-dim)' : 'var(--pf-muted)',
        border: active ? '1px solid var(--pf-accent)' : '1px solid var(--pf-border)',
        fontWeight: active ? 700 : 400,
        transition: 'border-color 0.15s, color 0.15s',
      }}
      onMouseEnter={e => { if (!disabled && !active) e.currentTarget.style.borderColor = 'var(--pf-accent)' }}
      onMouseLeave={e => { if (!disabled && !active) e.currentTarget.style.borderColor = 'var(--pf-border)' }}>
      {children}
    </button>
  )
}
