import { useState, useEffect } from 'react'
import { Link, useParams } from 'react-router-dom'
import { portfolioApi } from '../../api'
import { PORTFOLIO_USERNAME } from '../../config'
import { Spinner } from '../../components/ui'
import { ArrowLeft, Calendar, Tag, Clock } from 'lucide-react'

const fmtDate = d => {
  if (!d) return ''
  try { return new Date(d).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) }
  catch { return '' }
}

// Reading time estimate
const readTime = content => {
  if (!content) return 1
  const words = content.trim().split(/\s+/).length
  return Math.max(1, Math.round(words / 200))
}

// ── Minimal markdown renderer ─────────────────────────────────────────
function Markdown({ content }) {
  if (!content) return null

  const lines   = content.split('\n')
  const els     = []
  let listBuf   = []
  let olBuf     = []
  let key       = 0

  const inlineHtml = text => {
    return text
      .replace(/`([^`]+)`/g,             (_, c)         => `<code style="background:rgba(200,169,110,0.12);color:var(--pf-accent2);padding:1px 6px;border-radius:4px;font-size:0.88em">${c}</code>`)
      .replace(/\*\*\*([^*]+)\*\*\*/g,   (_, t)         => `<strong><em>${t}</em></strong>`)
      .replace(/\*\*([^*]+)\*\*/g,       (_, t)         => `<strong>${t}</strong>`)
      .replace(/\*([^*]+)\*/g,           (_, t)         => `<em>${t}</em>`)
      .replace(/~~([^~]+)~~/g,           (_, t)         => `<del>${t}</del>`)
      .replace(/\[([^\]]+)\]\(([^)]+)\)/g,(_, l, u)     => `<a href="${u}" target="_blank" rel="noreferrer" style="color:var(--pf-accent);text-decoration:underline;text-underline-offset:3px">${l}</a>`)
  }

  const renderInline = text => {
    const html = inlineHtml(text)
    if (html === text) return text
    return <span key={key++} dangerouslySetInnerHTML={{ __html: html }} />
  }

  const flushList = () => {
    if (listBuf.length) {
      els.push(
        <ul key={key++} style={{ paddingLeft: '1.6rem', marginBottom: '1.4rem', color: 'var(--pf-muted)', display: 'flex', flexDirection: 'column', gap: '0.4rem', listStyleType: 'disc' }}>
          {listBuf.map((item, i) => <li key={i} style={{ lineHeight: 1.75, fontSize: '1.02rem' }}>{renderInline(item)}</li>)}
        </ul>
      )
      listBuf = []
    }
    if (olBuf.length) {
      els.push(
        <ol key={key++} style={{ paddingLeft: '1.6rem', marginBottom: '1.4rem', color: 'var(--pf-muted)', display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
          {olBuf.map((item, i) => <li key={i} style={{ lineHeight: 1.75, fontSize: '1.02rem' }}>{renderInline(item)}</li>)}
        </ol>
      )
      olBuf = []
    }
  }

  const HEAD_SIZES  = ['2.1rem', '1.65rem', '1.35rem', '1.15rem', '1rem', '0.95rem']
  const HEAD_MT     = ['2.5rem', '2rem', '1.75rem', '1.5rem', '1.25rem', '1rem']

  let i = 0
  while (i < lines.length) {
    const line = lines[i]

    // Headings
    if (/^#{1,6}\s/.test(line)) {
      flushList()
      const lvl  = line.match(/^(#+)/)[1].length
      const text = line.replace(/^#+\s/, '')
      els.push(
        <div key={key++} style={{ fontFamily: "'DM Serif Display', serif", fontSize: HEAD_SIZES[lvl - 1], fontWeight: 400, lineHeight: 1.2, color: 'var(--pf-text)', marginTop: HEAD_MT[lvl - 1], marginBottom: '0.75rem' }}>
          {renderInline(text)}
        </div>
      )
    }
    // Horizontal rule
    else if (/^(-{3,}|\*{3,})$/.test(line.trim())) {
      flushList()
      els.push(<hr key={key++} style={{ border: 'none', borderTop: '1px solid var(--pf-border)', margin: '2.5rem 0' }} />)
    }
    // Blockquote
    else if (/^>\s/.test(line)) {
      flushList()
      const text = line.replace(/^>\s/, '')
      els.push(
        <blockquote key={key++} style={{ borderLeft: `3px solid var(--pf-accent)`, paddingLeft: '1.25rem', margin: '1.5rem 0', color: 'var(--pf-muted)', fontStyle: 'italic', fontSize: '1.05rem', lineHeight: 1.75 }}>
          {renderInline(text)}
        </blockquote>
      )
    }
    // Unordered list
    else if (/^[-*]\s/.test(line)) {
      olBuf.length && flushList()
      listBuf.push(line.replace(/^[-*]\s/, ''))
    }
    // Ordered list
    else if (/^\d+\.\s/.test(line)) {
      listBuf.length && flushList()
      olBuf.push(line.replace(/^\d+\.\s/, ''))
    }
    // Fenced code block
    else if (/^```/.test(line)) {
      flushList()
      const lang = line.slice(3).trim()
      const codeLines = []
      i++
      while (i < lines.length && !/^```/.test(lines[i])) { codeLines.push(lines[i]); i++ }
      els.push(
        <div key={key++} style={{ position: 'relative', marginBottom: '1.75rem' }}>
          {lang && (
            <div style={{ background: 'var(--pf-border)', padding: '4px 12px', borderRadius: '8px 8px 0 0', fontSize: '0.72rem', color: 'var(--pf-dim)', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>
              {lang}
            </div>
          )}
          <pre style={{ background: 'var(--pf-card)', border: '1px solid var(--pf-border)', borderRadius: lang ? '0 0 8px 8px' : 8, padding: '1.25rem 1.5rem', overflowX: 'auto', fontSize: '0.875rem', lineHeight: 1.7, color: '#a8b8d8', fontFamily: "'Fira Code', 'Cascadia Code', monospace", margin: 0 }}>
            <code>{codeLines.join('\n')}</code>
          </pre>
        </div>
      )
    }
    // Blank line
    else if (line.trim() === '') {
      flushList()
    }
    // Paragraph
    else {
      flushList()
      els.push(
        <p key={key++} style={{ fontSize: '1.05rem', lineHeight: 1.85, color: 'var(--pf-muted)', marginBottom: '1.25rem' }}>
          {renderInline(line)}
        </p>
      )
    }
    i++
  }

  flushList()
  return <div>{els}</div>
}

// ── Main page ─────────────────────────────────────────────────────────
export default function BlogPostPage() {
  const { slug }                = useParams()
  const [post, setPost]         = useState(null)
  const [loading, setLoading]   = useState(true)
  const [notFound, setNotFound] = useState(false)
  const [imgErr, setImgErr]     = useState(false)

  useEffect(() => {
    setLoading(true)
    portfolioApi.getBlogPost(PORTFOLIO_USERNAME, slug)
      .then(r  => setPost(r.data.data))
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false))
  }, [slug])

  if (loading) return (
    <div className="pf-root" style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Spinner size={32} />
    </div>
  )

  if (notFound || !post) return (
    <div className="pf-root" style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '1rem', textAlign: 'center', padding: '2rem' }}>
      <p style={{ fontSize: '3.5rem' }}>📄</p>
      <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: '1.8rem' }}>Article not found</h2>
      <p style={{ color: 'var(--pf-muted)' }}>This post doesn't exist or was unpublished.</p>
      <Link to="/blog" style={{ color: 'var(--pf-accent)', fontSize: '0.9rem', textDecoration: 'none' }}>← Back to all articles</Link>
    </div>
  )

  const mins = readTime(post.content)

  return (
    <div className="pf-root" style={{ minHeight: '100vh' }}>

      {/* Cover image */}
      {post.imageUrl && !imgErr && (
        <div style={{ width: '100%', height: 'clamp(220px, 42vh, 440px)', overflow: 'hidden', position: 'relative' }}>
          <img
            src={post.imageUrl} alt={post.title}
            onError={() => setImgErr(true)}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
          {/* Fade-out gradient at bottom */}
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, transparent 40%, var(--pf-bg) 100%)' }} />
        </div>
      )}

      {/* Content */}
      <div style={{ maxWidth: 740, margin: '0 auto', padding: `${post.imageUrl && !imgErr ? '2rem' : '5rem'} 1.5rem 6rem` }}>

        {/* Back link */}
        <Link to="/blog"
          style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'var(--pf-muted)', fontSize: '0.85rem', textDecoration: 'none', marginBottom: '2rem', transition: 'color 0.15s' }}
          onMouseEnter={e => e.currentTarget.style.color = 'var(--pf-accent)'}
          onMouseLeave={e => e.currentTarget.style.color = 'var(--pf-muted)'}>
          <ArrowLeft size={15} /> All articles
        </Link>

        {/* Meta row */}
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', alignItems: 'center', marginBottom: '1.25rem' }}>
          {post.categoryName && (
            <span className="pf-tag" style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <Tag size={9} /> {post.categoryName}
            </span>
          )}
          <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: '0.78rem', color: 'var(--pf-dim)' }}>
            <Calendar size={12} /> {fmtDate(post.publishedAt)}
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: '0.78rem', color: 'var(--pf-dim)' }}>
            <Clock size={12} /> {mins} min read
          </span>
        </div>

        {/* Title */}
        <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 'clamp(2rem, 5.5vw, 3rem)', fontWeight: 400, lineHeight: 1.12, letterSpacing: '-0.025em', marginBottom: post.summary ? '1rem' : '2.5rem', color: 'var(--pf-text)' }}>
          {post.title}
        </h1>

        {/* Summary / lead */}
        {post.summary && (
          <p style={{ fontSize: '1.12rem', color: 'var(--pf-muted)', lineHeight: 1.7, fontStyle: 'italic', paddingBottom: '2rem', marginBottom: '2.5rem', borderBottom: '1px solid var(--pf-border)' }}>
            {post.summary}
          </p>
        )}

        {/* Article body */}
        <div>
          <Markdown content={post.content} />
        </div>

        {/* Footer nav */}
        <div style={{ marginTop: '4.5rem', paddingTop: '2rem', borderTop: '1px solid var(--pf-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <Link to="/blog"
            style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'var(--pf-accent)', fontSize: '0.875rem', textDecoration: 'none' }}>
            ← More articles
          </Link>
          <Link to="/"
            style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'var(--pf-muted)', fontSize: '0.875rem', textDecoration: 'none', transition: 'color 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--pf-accent)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--pf-muted)'}>
            Back to portfolio →
          </Link>
        </div>
      </div>
    </div>
  )
}
