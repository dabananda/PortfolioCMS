import { useState, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { portfolioApi } from '../../api'
import { PORTFOLIO_USERNAME } from '../../config'
import { Spinner } from '../../components/ui'
import {
  MapPin, Download, ExternalLink, GitBranch, Star, ChevronDown,
  Code2, Briefcase, GraduationCap, Award, Activity, MessageSquare,
  FileText, Terminal, Menu, X, ArrowUpRight, Mail,
} from 'lucide-react'

// ── Helpers ──────────────────────────────────────────────────────────
const fmtDate = d => {
  if (!d) return ''
  try { return new Date(String(d)).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) }
  catch { return String(d).slice(0, 7) }
}

const SOCIAL_ICONS = {
  github: 'GH', linkedin: 'in', twitter: '𝕏', x: '𝕏',
  facebook: 'f', instagram: 'IG', youtube: 'YT', website: '↗',
}
const socialIcon = (name = '') => {
  const k = name.toLowerCase()
  for (const [key, val] of Object.entries(SOCIAL_ICONS)) if (k.includes(key)) return val
  return '↗'
}

const PROFICIENCY_W  = { Beginner: 25, Intermediate: 50, Advanced: 75, Expert: 100 }
const STATUS_LABEL   = { Available: 'Available for work', OpenToWork: 'Open to work', Busy: 'Busy', NotAvailable: 'Not available' }
const STATUS_COLOR   = { Available: '#5cb87e', OpenToWork: '#5cb87e', Busy: '#e0a85c', NotAvailable: '#7a7a94' }

const NAV_ITEMS = [
  { id: 'about',         label: 'About'      },
  { id: 'skills',        label: 'Skills'     },
  { id: 'work',          label: 'Experience' },
  { id: 'projects',      label: 'Projects'   },
  { id: 'education',     label: 'Education'  },
  { id: 'blog',          label: 'Blog'       },
  { id: 'contact',       label: 'Contact'    },
]

function scrollTo(id) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

// ── Sticky Nav ────────────────────────────────────────────────────────
function Nav({ profile }) {
  const [scrolled, setScrolled] = useState(false)
  const [active, setActive]     = useState('')
  const [mobileOpen, setMobile] = useState(false)

  useEffect(() => {
    const fn = () => {
      setScrolled(window.scrollY > 60)
      for (const { id } of [...NAV_ITEMS].reverse()) {
        const el = document.getElementById(id)
        if (el && window.scrollY >= el.offsetTop - 130) { setActive(id); break }
      }
    }
    window.addEventListener('scroll', fn, { passive: true })
    return () => window.removeEventListener('scroll', fn)
  }, [])

  const go = id => { scrollTo(id); setMobile(false) }

  return (
    <header style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      background: scrolled ? 'rgba(8,8,11,0.93)' : 'transparent',
      backdropFilter: scrolled ? 'blur(14px)' : 'none',
      borderBottom: scrolled ? '1px solid rgba(34,34,48,0.8)' : '1px solid transparent',
      transition: 'all 0.28s ease',
    }}>
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '0 1.5rem', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        {/* Brand */}
        <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: "'DM Serif Display', serif", fontSize: '1.1rem', color: 'var(--pf-accent)', letterSpacing: '-0.01em' }}>
          {profile?.firstName} {profile?.lastName}
        </button>

        {/* Desktop links */}
        <nav style={{ display: 'flex', gap: '1.75rem' }} className="pf-desktop-nav">
          {NAV_ITEMS.map(({ id, label }) => (
            <button key={id} onClick={() => go(id)} style={{
              background: 'none', border: 'none', borderBottom: `2px solid ${active === id ? 'var(--pf-accent)' : 'transparent'}`,
              cursor: 'pointer', fontFamily: 'inherit', fontSize: '0.84rem', padding: '0.3rem 0',
              color: active === id ? 'var(--pf-accent)' : 'var(--pf-muted)', transition: 'color 0.15s, border-color 0.15s',
            }}
            onMouseEnter={e => { if (active !== id) e.currentTarget.style.color = 'var(--pf-text)' }}
            onMouseLeave={e => { if (active !== id) e.currentTarget.style.color = 'var(--pf-muted)' }}>
              {label}
            </button>
          ))}
        </nav>

        {/* Login link (top right) */}
        <Link to="/login" className="pf-desktop-nav" style={{ fontSize: '0.82rem', color: 'var(--pf-dim)', textDecoration: 'none', border: '1px solid var(--pf-border)', padding: '0.3rem 0.8rem', borderRadius: 6, transition: 'border-color 0.15s, color 0.15s' }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--pf-accent)'; e.currentTarget.style.color = 'var(--pf-accent)' }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--pf-border)'; e.currentTarget.style.color = 'var(--pf-dim)' }}>
          Login
        </Link>

        {/* Mobile hamburger */}
        <button onClick={() => setMobile(o => !o)} className="pf-mobile-hamburger"
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--pf-muted)', display: 'none', padding: 4 }}>
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div style={{ background: 'rgba(8,8,11,0.97)', borderTop: '1px solid var(--pf-border)', padding: '0.75rem 1.5rem 1.25rem', display: 'flex', flexDirection: 'column', gap: '0.15rem' }}>
          {NAV_ITEMS.map(({ id, label }) => (
            <button key={id} onClick={() => go(id)} style={{
              background: 'none', border: 'none', borderBottom: '1px solid var(--pf-border)',
              cursor: 'pointer', fontFamily: 'inherit', textAlign: 'left',
              padding: '0.65rem 0', fontSize: '1rem',
              color: active === id ? 'var(--pf-accent)' : 'var(--pf-muted)', transition: 'color 0.15s',
            }}>{label}</button>
          ))}
          <Link to="/login" onClick={() => setMobile(false)} style={{ display: 'block', padding: '0.65rem 0', fontSize: '0.9rem', color: 'var(--pf-dim)', textDecoration: 'none', marginTop: 4 }}>
            Login →
          </Link>
        </div>
      )}

      <style>{`
        @media (max-width: 700px) {
          .pf-desktop-nav    { display: none !important; }
          .pf-mobile-hamburger { display: flex !important; }
        }
      `}</style>
    </header>
  )
}

// ── Hero ──────────────────────────────────────────────────────────────
function Hero({ data }) {
  const { profile, socialLinks } = data
  const [imgErr, setImgErr] = useState(false)
  const statusColor = STATUS_COLOR[profile.status] || '#7a7a94'
  const statusLabel = STATUS_LABEL[profile.status] || profile.status

  return (
    <section style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', padding: '6rem 0 4rem', position: 'relative', overflow: 'hidden' }}>
      {/* Ambient glows */}
      <div style={{ position: 'absolute', top: '-15%', right: '-8%', width: '55vw', height: '55vw', borderRadius: '50%', background: 'radial-gradient(circle, rgba(200,169,110,0.055) 0%, transparent 65%)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', bottom: '0', left: '-12%', width: '45vw', height: '45vw', borderRadius: '50%', background: 'radial-gradient(circle, rgba(111,163,224,0.04) 0%, transparent 65%)', pointerEvents: 'none' }} />

      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '0 1.5rem', width: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '5rem', flexWrap: 'wrap-reverse' }}>

          {/* Text */}
          <div style={{ flex: '1 1 380px' }} className="pf-fade-up">
            {/* Status */}
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 12px', borderRadius: 20, border: `1px solid ${statusColor}35`, background: `${statusColor}0f`, marginBottom: '1.75rem' }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: statusColor, display: 'inline-block', boxShadow: `0 0 6px ${statusColor}` }} />
              <span style={{ fontSize: '0.78rem', color: statusColor, fontWeight: 500 }}>{statusLabel}</span>
            </div>

            {/* Name */}
            <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 'clamp(2.5rem, 7vw, 4rem)', fontWeight: 400, lineHeight: 1.08, letterSpacing: '-0.025em', marginBottom: '1.1rem' }}>
              {profile.firstName}<br /><span style={{ color: 'var(--pf-accent)' }}>{profile.lastName}</span>
            </h1>

            {profile.headLine && (
              <p style={{ fontSize: 'clamp(1rem, 2.5vw, 1.2rem)', color: 'var(--pf-muted)', marginBottom: '1.4rem', lineHeight: 1.55, maxWidth: 480 }}>
                {profile.headLine}
              </p>
            )}

            {profile.location && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--pf-dim)', fontSize: '0.875rem', marginBottom: '2.25rem' }}>
                <MapPin size={14} />{profile.location}
              </div>
            )}

            {/* CTA buttons */}
            <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', marginBottom: '2.75rem' }}>
              <button onClick={() => scrollTo('contact')}
                style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '0.65rem 1.5rem', borderRadius: 8, background: 'var(--pf-accent)', color: '#0c0c0f', fontWeight: 600, fontSize: '0.9rem', border: 'none', cursor: 'pointer', fontFamily: 'inherit', transition: 'background 0.15s, transform 0.15s' }}
                onMouseEnter={e => { e.currentTarget.style.background = 'var(--pf-accent2)'; e.currentTarget.style.transform = 'translateY(-1px)' }}
                onMouseLeave={e => { e.currentTarget.style.background = 'var(--pf-accent)';  e.currentTarget.style.transform = 'none' }}>
                <Mail size={15} /> Get in touch
              </button>
              {profile.resumeUrl && (
                <a href={profile.resumeUrl} target="_blank" rel="noreferrer"
                  style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '0.65rem 1.5rem', borderRadius: 8, background: 'transparent', color: 'var(--pf-text)', fontWeight: 500, fontSize: '0.9rem', border: '1px solid var(--pf-border)', textDecoration: 'none', transition: 'border-color 0.15s, transform 0.15s' }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--pf-accent)'; e.currentTarget.style.transform = 'translateY(-1px)' }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--pf-border)'; e.currentTarget.style.transform = 'none' }}>
                  <Download size={15} /> Resume
                </a>
              )}
            </div>

            {/* Social links */}
            {socialLinks?.length > 0 && (
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                {socialLinks.map(s => (
                  <a key={s.id} href={s.link} target="_blank" rel="noreferrer" title={s.name}
                    style={{ width: 38, height: 38, borderRadius: 8, border: '1px solid var(--pf-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--pf-muted)', fontSize: '0.75rem', fontWeight: 700, textDecoration: 'none', transition: 'border-color 0.15s, color 0.15s, transform 0.15s' }}
                    onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--pf-accent)'; e.currentTarget.style.color = 'var(--pf-accent)'; e.currentTarget.style.transform = 'translateY(-2px)' }}
                    onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--pf-border)'; e.currentTarget.style.color = 'var(--pf-muted)'; e.currentTarget.style.transform = 'none' }}>
                    {socialIcon(s.name)}
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* Avatar */}
          <div style={{ flex: '0 0 auto', display: 'flex', justifyContent: 'center' }}>
            <div style={{ position: 'relative' }}>
              <div style={{ position: 'absolute', inset: -2, borderRadius: '50%', background: `conic-gradient(from 180deg, transparent 0%, ${statusColor}55 25%, transparent 50%, ${statusColor}30 75%, transparent 100%)`, animation: 'spin 10s linear infinite' }} />
              <div style={{ width: 'clamp(190px, 22vw, 250px)', height: 'clamp(190px, 22vw, 250px)', borderRadius: '50%', overflow: 'hidden', background: 'var(--pf-card)', border: '2px solid var(--pf-border)', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {profile.imageUrl && !imgErr ? (
                  <img src={profile.imageUrl} alt={`${profile.firstName} ${profile.lastName}`} onError={() => setImgErr(true)}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                  <span style={{ fontFamily: "'DM Serif Display', serif", fontSize: 'clamp(3rem, 7vw, 5rem)', color: 'var(--pf-accent)', opacity: 0.5 }}>
                    {profile.firstName?.[0]}{profile.lastName?.[0]}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Scroll nudge */}
        <div style={{ position: 'absolute', bottom: '2.5rem', left: '50%', transform: 'translateX(-50%)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, color: 'var(--pf-dim)', fontSize: '0.7rem', letterSpacing: '0.05em', textTransform: 'uppercase', opacity: 0.6 }}>
          <span>scroll</span>
          <ChevronDown size={14} style={{ animation: 'bounce 2s ease-in-out infinite' }} />
        </div>
      </div>
      <style>{`@keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(5px)} }`}</style>
    </section>
  )
}

// ── Section wrapper ───────────────────────────────────────────────────
function Sec({ id, bg, children }) {
  return (
    <section id={id} style={{ padding: '5.5rem 0', background: bg || 'transparent' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '0 1.5rem' }}>
        {children}
      </div>
    </section>
  )
}

function Title({ pre, accent }) {
  return (
    <h2 className="pf-section-title">
      {pre && <>{pre} </>}<span style={{ color: 'var(--pf-accent)' }}>{accent}</span>
    </h2>
  )
}

// ── About stats ───────────────────────────────────────────────────────
function About({ data }) {
  const stats = [
    { label: 'Skills',      value: data.skills?.length || 0,          icon: Code2 },
    { label: 'Projects',    value: data.projects?.length || 0,        icon: Briefcase },
    { label: 'Experiences', value: data.workExperiences?.length || 0, icon: Activity },
    { label: 'Certs',       value: data.certifications?.length || 0,  icon: Award },
  ]
  return (
    <Sec id="about">
      <Title pre="About" accent="Me" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem' }}>
        {stats.map(({ label, value, icon: Icon }) => (
          <div key={label} className="pf-card" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ width: 44, height: 44, borderRadius: 10, background: 'rgba(200,169,110,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Icon size={20} style={{ color: 'var(--pf-accent)' }} />
            </div>
            <div>
              <p style={{ fontSize: '1.65rem', fontFamily: "'DM Serif Display', serif", lineHeight: 1 }}>{value}</p>
              <p style={{ fontSize: '0.78rem', color: 'var(--pf-muted)', marginTop: 2 }}>{label}</p>
            </div>
          </div>
        ))}
      </div>
    </Sec>
  )
}

// ── Skills ────────────────────────────────────────────────────────────
function Skills({ skills }) {
  if (!skills?.length) return null
  const grouped = skills.reduce((acc, s) => { const c = s.category || 'General'; (acc[c] = acc[c] || []).push(s); return acc }, {})
  return (
    <Sec id="skills" bg="var(--pf-surface)">
      <Title pre="Technical" accent="Skills" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.25rem' }}>
        {Object.entries(grouped).map(([cat, items]) => (
          <div key={cat} className="pf-card" style={{ padding: '1.5rem' }}>
            <p style={{ fontSize: '0.68rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--pf-accent)', marginBottom: '1.1rem' }}>{cat}</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
              {items.map(s => (
                <div key={s.id}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                    <span style={{ fontSize: '0.875rem', fontWeight: 500 }}>{s.skillName}</span>
                    <span style={{ fontSize: '0.71rem', color: 'var(--pf-dim)' }}>{s.proficiency}</span>
                  </div>
                  <div style={{ height: 3, background: 'var(--pf-border)', borderRadius: 2, overflow: 'hidden' }}>
                    <div style={{ width: `${PROFICIENCY_W[s.proficiency] || 50}%`, height: '100%', background: 'linear-gradient(90deg, var(--pf-accent), var(--pf-accent2))', borderRadius: 2 }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Sec>
  )
}

// ── Timeline helper ───────────────────────────────────────────────────
function Timeline({ items, renderItem }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      {items.map((item, i) => (
        <div key={item.id} style={{ display: 'flex', gap: '2rem', paddingBottom: i < items.length - 1 ? '2.5rem' : 0 }}>
          <div style={{ position: 'relative', paddingLeft: 22, flexShrink: 0 }}>
            {i < items.length - 1 && <div className="pf-timeline-line" />}
            <div className="pf-timeline-dot" />
          </div>
          <div style={{ flex: 1 }}>{renderItem(item)}</div>
        </div>
      ))}
    </div>
  )
}

function DateBadge({ start, end }) {
  return (
    <span style={{ fontSize: '0.775rem', color: 'var(--pf-dim)', background: 'var(--pf-card)', padding: '3px 10px', borderRadius: 20, border: '1px solid var(--pf-border)', whiteSpace: 'nowrap', flexShrink: 0 }}>
      {fmtDate(start)} — {end ? fmtDate(end) : 'Present'}
    </span>
  )
}

// ── Work Experience ───────────────────────────────────────────────────
function Work({ workExperiences }) {
  if (!workExperiences?.length) return null
  return (
    <Sec id="work">
      <Title pre="Work" accent="Experience" />
      <Timeline items={workExperiences} renderItem={w => (
        <div>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '1rem', flexWrap: 'wrap', marginBottom: 8 }}>
            <div>
              <h3 style={{ fontFamily: "'DM Serif Display', serif", fontSize: '1.2rem', fontWeight: 400 }}>{w.role}</h3>
              <p style={{ color: 'var(--pf-accent)', fontSize: '0.9rem', marginTop: 2 }}>{w.companyName}</p>
            </div>
            <DateBadge start={w.startDate} end={w.endDate} />
          </div>
          {w.workDescription && <p style={{ fontSize: '0.875rem', color: 'var(--pf-muted)', lineHeight: 1.75 }}>{w.workDescription}</p>}
        </div>
      )} />
    </Sec>
  )
}

// ── Projects ──────────────────────────────────────────────────────────
function Projects({ projects }) {
  if (!projects?.length) return null
  return (
    <Sec id="projects" bg="var(--pf-surface)">
      <Title pre="Featured" accent="Projects" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.25rem' }}>
        {projects.map(p => (
          <div key={p.id} className="pf-card" style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <div style={{ height: 168, background: 'var(--pf-border)', overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {p.imageUrl ? (
                <img src={p.imageUrl} alt={p.title} onError={e => e.currentTarget.style.display = 'none'}
                  style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.35s' }}
                  onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.05)'}
                  onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'} />
              ) : (
                <Briefcase size={32} style={{ color: 'var(--pf-dim)', opacity: 0.4 }} />
              )}
            </div>
            <div style={{ padding: '1.25rem', flex: 1, display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <h3 style={{ fontFamily: "'DM Serif Display', serif", fontSize: '1.1rem', fontWeight: 400 }}>{p.title}</h3>
              <p style={{ fontSize: '0.845rem', color: 'var(--pf-muted)', lineHeight: 1.7, flex: 1 }}>
                {p.description.slice(0, 130)}{p.description.length > 130 ? '…' : ''}
              </p>
              {p.technologies?.length > 0 && (
                <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap' }}>
                  {p.technologies.slice(0, 5).map(t => <span key={t} className="pf-tag">{t}</span>)}
                </div>
              )}
              <div style={{ display: 'flex', gap: '1rem', paddingTop: '0.25rem' }}>
                {p.gitHubUrl && (
                  <a href={p.gitHubUrl} target="_blank" rel="noreferrer" style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: '0.8rem', color: 'var(--pf-muted)', textDecoration: 'none', transition: 'color 0.15s' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--pf-text)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--pf-muted)'}>
                    <GitBranch size={13} /> Code
                  </a>
                )}
                {p.liveUrl && (
                  <a href={p.liveUrl} target="_blank" rel="noreferrer" style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: '0.8rem', color: 'var(--pf-accent)', textDecoration: 'none', transition: 'color 0.15s' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--pf-accent2)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--pf-accent)'}>
                    <ExternalLink size={13} /> Live demo
                  </a>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Sec>
  )
}

// ── Education ─────────────────────────────────────────────────────────
function Education({ educations }) {
  if (!educations?.length) return null
  return (
    <Sec id="education">
      <Title accent="Education" />
      <Timeline items={educations} renderItem={e => (
        <div>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '1rem', flexWrap: 'wrap', marginBottom: 8 }}>
            <div>
              <h3 style={{ fontFamily: "'DM Serif Display', serif", fontSize: '1.15rem', fontWeight: 400 }}>{e.instituteName}</h3>
              <p style={{ color: 'var(--pf-muted)', fontSize: '0.875rem', marginTop: 2 }}>{e.department}</p>
            </div>
            <DateBadge start={e.startDate} end={e.endDate} />
          </div>
          <div style={{ display: 'flex', gap: '1.25rem', flexWrap: 'wrap' }}>
            {e.cgpa > 0 && <span style={{ fontSize: '0.82rem', color: 'var(--pf-accent)' }}>CGPA {e.cgpa} / {e.scale}</span>}
            {e.instituteLocation && <span style={{ fontSize: '0.82rem', color: 'var(--pf-dim)', display: 'flex', alignItems: 'center', gap: 4 }}><MapPin size={12} />{e.instituteLocation}</span>}
          </div>
        </div>
      )} />
    </Sec>
  )
}

// ── Certifications ────────────────────────────────────────────────────
function Certifications({ certifications }) {
  if (!certifications?.length) return null
  return (
    <Sec id="certifications" bg="var(--pf-surface)">
      <Title accent="Certifications" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1rem' }}>
        {certifications.map(c => (
          <div key={c.id} className="pf-card" style={{ padding: '1.25rem', display: 'flex', gap: '1rem' }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: 'rgba(200,169,110,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Award size={18} style={{ color: 'var(--pf-accent)' }} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.5rem' }}>
                <p style={{ fontWeight: 500, fontSize: '0.9rem', lineHeight: 1.35 }}>{c.certificationName}</p>
                {c.certificateUrl && <a href={c.certificateUrl} target="_blank" rel="noreferrer" style={{ color: 'var(--pf-accent)', flexShrink: 0 }}><ArrowUpRight size={14} /></a>}
              </div>
              <p style={{ fontSize: '0.8rem', color: 'var(--pf-muted)', marginTop: 3 }}>{c.issuingOrganization}</p>
              <p style={{ fontSize: '0.75rem', color: 'var(--pf-dim)', marginTop: 4 }}>{fmtDate(c.dateObtained)}</p>
            </div>
          </div>
        ))}
      </div>
    </Sec>
  )
}

// ── Problem Solving ───────────────────────────────────────────────────
function ProblemSolving({ problemSolvings }) {
  if (!problemSolvings?.length) return null
  return (
    <Sec id="problem-solving">
      <Title pre="Problem" accent="Solving" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem' }}>
        {problemSolvings.map(p => (
          <a key={p.id} href={p.profileUrl} target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
            <div className="pf-card" style={{ padding: '1.75rem', textAlign: 'center', cursor: 'pointer' }}>
              <p style={{ fontSize: '2.4rem', fontFamily: "'DM Serif Display', serif", color: 'var(--pf-accent)', lineHeight: 1 }}>{p.totalSolved}</p>
              <p style={{ fontSize: '0.7rem', color: 'var(--pf-dim)', marginTop: 2 }}>problems solved</p>
              <p style={{ fontWeight: 600, fontSize: '0.92rem', marginTop: '0.9rem' }}>{p.judgeName}</p>
              {p.handle && <p style={{ fontSize: '0.775rem', color: 'var(--pf-muted)', marginTop: 2 }}>@{p.handle}</p>}
              {p.rank && <span className="pf-tag" style={{ display: 'inline-block', marginTop: 8 }}>{p.rank}</span>}
            </div>
          </a>
        ))}
      </div>
    </Sec>
  )
}

// ── Reviews ───────────────────────────────────────────────────────────
function Reviews({ reviews }) {
  if (!reviews?.length) return null
  return (
    <Sec id="reviews" bg="var(--pf-surface)">
      <Title pre="What People" accent="Say" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.25rem' }}>
        {reviews.map(r => (
          <div key={r.id} className="pf-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ display: 'flex', gap: '0.2rem' }}>
              {[1,2,3,4,5].map(i => <Star key={i} size={14} style={{ color: i <= r.rating ? 'var(--pf-accent)' : 'var(--pf-border)', fill: i <= r.rating ? 'var(--pf-accent)' : 'none' }} />)}
            </div>
            <p style={{ fontSize: '0.9rem', color: 'var(--pf-muted)', lineHeight: 1.75, fontStyle: 'italic', flex: 1 }}>"{r.comment}"</p>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', paddingTop: '0.75rem', borderTop: '1px solid var(--pf-border)' }}>
              <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'rgba(200,169,110,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--pf-accent)', fontWeight: 700, fontSize: '0.85rem', flexShrink: 0 }}>{r.name?.[0]}</div>
              <div>
                <p style={{ fontSize: '0.875rem', fontWeight: 500 }}>{r.name}</p>
                {r.designation && <p style={{ fontSize: '0.75rem', color: 'var(--pf-dim)' }}>{r.designation}</p>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Sec>
  )
}

// ── Activities ────────────────────────────────────────────────────────
function Activities({ extraCurricularActivities }) {
  if (!extraCurricularActivities?.length) return null
  return (
    <Sec id="activities">
      <Title pre="Extra" accent="Activities" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1rem' }}>
        {extraCurricularActivities.map(a => (
          <div key={a.id} className="pf-card" style={{ padding: '1.25rem' }}>
            <p style={{ fontWeight: 600, fontSize: '0.9rem' }}>{a.title}</p>
            <p style={{ fontSize: '0.82rem', color: 'var(--pf-accent)', margin: '3px 0 4px' }}>{a.organization}</p>
            <p style={{ fontSize: '0.775rem', color: 'var(--pf-dim)', marginBottom: 8 }}>{fmtDate(a.startDate)} — {a.endDate ? fmtDate(a.endDate) : 'Present'}</p>
            <p style={{ fontSize: '0.845rem', color: 'var(--pf-muted)', lineHeight: 1.65 }}>{a.description}</p>
          </div>
        ))}
      </div>
    </Sec>
  )
}

// ── Blog preview ──────────────────────────────────────────────────────
function BlogPreview({ posts }) {
  if (!posts?.length) return null
  return (
    <Sec id="blog" bg="var(--pf-surface)">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '2rem', flexWrap: 'wrap', gap: '0.75rem' }}>
        <h2 className="pf-section-title" style={{ marginBottom: 0 }}>Recent <span style={{ color: 'var(--pf-accent)' }}>Articles</span></h2>
        <Link to="/blog" style={{ fontSize: '0.84rem', color: 'var(--pf-accent)', display: 'flex', alignItems: 'center', gap: 4, textDecoration: 'none' }}>
          All articles <ArrowUpRight size={14} />
        </Link>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.25rem' }}>
        {posts.slice(0, 3).map(p => (
          <Link key={p.id} to={`/blog/${p.slug}`} style={{ textDecoration: 'none' }}>
            <div className="pf-card" style={{ overflow: 'hidden', display: 'flex', flexDirection: 'column', height: '100%' }}>
              {p.imageUrl && (
                <div style={{ height: 148, overflow: 'hidden', flexShrink: 0 }}>
                  <img src={p.imageUrl} alt={p.title} onError={e => e.currentTarget.parentElement.style.display = 'none'}
                    style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.35s' }}
                    onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.05)'}
                    onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'} />
                </div>
              )}
              <div style={{ padding: '1.25rem', flex: 1 }}>
                {p.categoryName && <span className="pf-tag" style={{ marginBottom: '0.6rem', display: 'inline-block' }}>{p.categoryName}</span>}
                <h3 style={{ fontFamily: "'DM Serif Display', serif", fontSize: '1.05rem', fontWeight: 400, lineHeight: 1.35, marginBottom: 8, color: 'var(--pf-text)' }}>{p.title}</h3>
                {p.summary && <p style={{ fontSize: '0.84rem', color: 'var(--pf-muted)', lineHeight: 1.65 }}>{p.summary.slice(0, 100)}…</p>}
                <p style={{ fontSize: '0.75rem', color: 'var(--pf-dim)', marginTop: 10 }}>{fmtDate(p.publishedAt)}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </Sec>
  )
}

// ── Contact form ──────────────────────────────────────────────────────
function Contact() {
  const [form, setForm] = useState({ fullName: '', email: '', subject: '', description: '' })
  const [sending, setSending] = useState(false)
  const [sent, setSent]       = useState(false)
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async e => {
    e.preventDefault()
    setSending(true)
    try { await portfolioApi.contact(PORTFOLIO_USERNAME, form); setSent(true) }
    catch { setSent(true) } // graceful fallback
    finally { setSending(false) }
  }

  const inputSt = { background: 'var(--pf-card)', border: '1px solid var(--pf-border)', color: 'var(--pf-text)', borderRadius: 8, padding: '0.65rem 1rem', width: '100%', fontFamily: 'inherit', fontSize: '0.9rem', outline: 'none', transition: 'border-color 0.2s' }
  const focus = e => e.target.style.borderColor = 'var(--pf-accent)'
  const blur  = e => e.target.style.borderColor = 'var(--pf-border)'

  return (
    <Sec id="contact">
      <div style={{ maxWidth: 580, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '2.75rem' }}>
          <h2 className="pf-section-title" style={{ marginBottom: '0.5rem' }}>Get In <span style={{ color: 'var(--pf-accent)' }}>Touch</span></h2>
          <p style={{ color: 'var(--pf-muted)', fontSize: '0.9rem' }}>Have a project in mind or just want to say hi?</p>
        </div>

        {sent ? (
          <div style={{ textAlign: 'center', padding: '3rem 2rem', background: 'var(--pf-card)', border: '1px solid var(--pf-border)', borderRadius: 12 }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'rgba(92,184,126,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.25rem', fontSize: '1.5rem' }}>✓</div>
            <h3 style={{ fontFamily: "'DM Serif Display', serif", marginBottom: '0.5rem' }}>Message sent!</h3>
            <p style={{ color: 'var(--pf-muted)', fontSize: '0.875rem' }}>Thanks for reaching out. I'll get back to you soon.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                <label style={{ fontSize: '0.78rem', color: 'var(--pf-muted)', fontWeight: 500 }}>Name *</label>
                <input value={form.fullName} onChange={set('fullName')} placeholder="Your name" required style={inputSt} onFocus={focus} onBlur={blur} />
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                <label style={{ fontSize: '0.78rem', color: 'var(--pf-muted)', fontWeight: 500 }}>Email *</label>
                <input type="email" value={form.email} onChange={set('email')} placeholder="your@email.com" required style={inputSt} onFocus={focus} onBlur={blur} />
              </div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
              <label style={{ fontSize: '0.78rem', color: 'var(--pf-muted)', fontWeight: 500 }}>Subject</label>
              <input value={form.subject} onChange={set('subject')} placeholder="What's this about?" style={inputSt} onFocus={focus} onBlur={blur} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
              <label style={{ fontSize: '0.78rem', color: 'var(--pf-muted)', fontWeight: 500 }}>Message *</label>
              <textarea rows={5} value={form.description} onChange={set('description')} placeholder="Tell me more…" required style={{ ...inputSt, resize: 'vertical' }} onFocus={focus} onBlur={blur} />
            </div>
            <button type="submit" disabled={sending}
              style={{ padding: '0.7rem 2rem', borderRadius: 8, background: 'var(--pf-accent)', color: '#0c0c0f', fontWeight: 600, fontSize: '0.92rem', border: 'none', cursor: 'pointer', alignSelf: 'flex-end', fontFamily: 'inherit', opacity: sending ? 0.7 : 1, transition: 'background 0.15s, transform 0.15s' }}
              onMouseEnter={e => { if (!sending) { e.currentTarget.style.background = 'var(--pf-accent2)'; e.currentTarget.style.transform = 'translateY(-1px)' } }}
              onMouseLeave={e => { e.currentTarget.style.background = 'var(--pf-accent)'; e.currentTarget.style.transform = 'none' }}>
              {sending ? 'Sending…' : 'Send message →'}
            </button>
          </form>
        )}
      </div>
    </Sec>
  )
}

// ── Footer ────────────────────────────────────────────────────────────
function Footer({ profile }) {
  return (
    <footer style={{ padding: '2rem 1.5rem', borderTop: '1px solid var(--pf-border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem', maxWidth: 1100, margin: '0 auto' }}>
      <p style={{ fontSize: '0.8rem', color: 'var(--pf-dim)' }}>
        © {new Date().getFullYear()} {profile?.firstName} {profile?.lastName}
      </p>
      <Link to="/dashboard" style={{ fontSize: '0.78rem', color: 'var(--pf-dim)', textDecoration: 'none', transition: 'color 0.15s' }}
        onMouseEnter={e => e.currentTarget.style.color = 'var(--pf-accent)'}
        onMouseLeave={e => e.currentTarget.style.color = 'var(--pf-dim)'}>
        Dashboard →
      </Link>
    </footer>
  )
}

// ── Not found ────────────────────────────────────────────────────────
function NotConfigured() {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '1rem', textAlign: 'center', padding: '2rem' }}>
      <p style={{ fontSize: '3.5rem' }}>⚙️</p>
      <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: '2rem' }}>Portfolio not configured</h1>
      <p style={{ color: 'var(--pf-muted)', maxWidth: 420, lineHeight: 1.65 }}>
        Set <code style={{ background: 'var(--pf-card)', padding: '2px 6px', borderRadius: 4 }}>VITE_PORTFOLIO_USERNAME</code> in your <code style={{ background: 'var(--pf-card)', padding: '2px 6px', borderRadius: 4 }}>.env</code> file and rebuild.
      </p>
      <Link to="/dashboard" style={{ color: 'var(--pf-accent)', fontSize: '0.9rem' }}>Go to dashboard →</Link>
    </div>
  )
}

// ── Main export ───────────────────────────────────────────────────────
export default function PortfolioPage() {
  const [data, setData]       = useState(null)
  const [blogPosts, setBlog]  = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError]     = useState(false)

  useEffect(() => {
    if (!PORTFOLIO_USERNAME) { setLoading(false); return }
    Promise.all([
      portfolioApi.get(PORTFOLIO_USERNAME),
      portfolioApi.getBlog(PORTFOLIO_USERNAME, { page: 1, pageSize: 3 }),
    ]).then(([pf, blog]) => {
      setData(pf.data.data)
      const d = blog.data.data
      setBlog(Array.isArray(d) ? d : d?.items || [])
    }).catch(() => setError(true))
    .finally(() => setLoading(false))
  }, [])

  if (!PORTFOLIO_USERNAME) return <div className="pf-root" style={{ minHeight: '100vh' }}><NotConfigured /></div>

  if (loading) return (
    <div className="pf-root" style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem' }}>
        <Spinner size={36} />
        <p style={{ color: 'var(--pf-muted)', fontSize: '0.875rem' }}>Loading portfolio…</p>
      </div>
    </div>
  )

  if (error || !data) return (
    <div className="pf-root" style={{ minHeight: '100vh' }}>
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '1rem', textAlign: 'center', padding: '2rem' }}>
        <p style={{ fontSize: '3.5rem' }}>🔍</p>
        <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: '2rem' }}>Portfolio not found</h1>
        <p style={{ color: 'var(--pf-muted)' }}>No public portfolio for <strong>@{PORTFOLIO_USERNAME}</strong> found.</p>
        <Link to="/dashboard" style={{ color: 'var(--pf-accent)', fontSize: '0.9rem' }}>Go to dashboard →</Link>
      </div>
    </div>
  )

  return (
    <div className="pf-root" style={{ minHeight: '100vh' }}>
      <Nav profile={data.profile} />
      <Hero          data={data} />
      <About         data={data} />
      <Skills        skills={data.skills} />
      <Work          workExperiences={data.workExperiences} />
      <Projects      projects={data.projects} />
      <Education     educations={data.educations} />
      <Certifications certifications={data.certifications} />
      <ProblemSolving problemSolvings={data.problemSolvings} />
      <Reviews       reviews={data.reviews} />
      <Activities    extraCurricularActivities={data.extraCurricularActivities} />
      <BlogPreview   posts={blogPosts} />
      <Contact />
      <Footer        profile={data.profile} />
    </div>
  )
}
