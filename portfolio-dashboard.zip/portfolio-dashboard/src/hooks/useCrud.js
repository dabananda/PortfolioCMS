import { useState, useEffect, useCallback } from 'react'
import toast from 'react-hot-toast'

export function useCrud(fetchFn, { extractData = d => d } = {}) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await fetchFn()
      const extracted = extractData(data.data)
      setItems(Array.isArray(extracted) ? extracted : [])
      setError(null)
    } catch (err) {
      setError(err)
      toast.error(err?.response?.data?.message || 'Failed to load data')
    } finally { setLoading(false) }
  }, [fetchFn])

  useEffect(() => { load() }, [load])

  return { items, setItems, loading, error, reload: load }
}
