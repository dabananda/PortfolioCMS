import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider, useAuth } from './context/AuthContext'
import Layout from './components/layout/Layout'

// Auth pages
import Login          from './pages/auth/Login'
import Register       from './pages/auth/Register'
import ForgotPassword from './pages/auth/ForgotPassword'

// Dashboard pages
import Dashboard      from './pages/dashboard/Dashboard'
import Profile        from './pages/dashboard/Profile'
import BlogPosts      from './pages/dashboard/BlogPosts'
import Categories     from './pages/dashboard/Categories'
import Skills         from './pages/dashboard/Skills'
import Projects       from './pages/dashboard/Projects'
import Education      from './pages/dashboard/Education'
import WorkExperience from './pages/dashboard/WorkExperience'
import Certifications from './pages/dashboard/Certifications'
import SocialLinks    from './pages/dashboard/SocialLinks'
import Reviews        from './pages/dashboard/Reviews'
import Activities     from './pages/dashboard/Activities'
import ProblemSolving from './pages/dashboard/ProblemSolving'
import Messages       from './pages/dashboard/Messages'
import Settings       from './pages/dashboard/Settings'

// Public portfolio pages
import PortfolioPage from './pages/portfolio/PortfolioPage'
import BlogListPage  from './pages/portfolio/BlogListPage'
import BlogPostPage  from './pages/portfolio/BlogPostPage'

// Route guards
function RequireAuth({ children }) {
  const { isAuthenticated } = useAuth()
  return isAuthenticated ? children : <Navigate to="/login" replace />
}
function RedirectIfAuth({ children }) {
  const { isAuthenticated } = useAuth()
  return isAuthenticated ? <Navigate to="/dashboard" replace /> : children
}

function AppRoutes() {
  return (
    <Routes>
      {/* ── Public portfolio (root of the site) ── */}
      <Route path="/"           element={<PortfolioPage />} />
      <Route path="/blog"       element={<BlogListPage />} />
      <Route path="/blog/:slug" element={<BlogPostPage />} />

      {/* ── Auth ── */}
      <Route path="/login"           element={<RedirectIfAuth><Login /></RedirectIfAuth>} />
      <Route path="/register"        element={<RedirectIfAuth><Register /></RedirectIfAuth>} />
      <Route path="/forgot-password" element={<ForgotPassword />} />

      {/* ── Dashboard ── */}
      <Route path="/dashboard"                  element={<RequireAuth><Layout><Dashboard /></Layout></RequireAuth>} />
      <Route path="/dashboard/profile"          element={<RequireAuth><Layout><Profile /></Layout></RequireAuth>} />
      <Route path="/dashboard/blog"             element={<RequireAuth><Layout><BlogPosts /></Layout></RequireAuth>} />
      <Route path="/dashboard/categories"       element={<RequireAuth><Layout><Categories /></Layout></RequireAuth>} />
      <Route path="/dashboard/skills"           element={<RequireAuth><Layout><Skills /></Layout></RequireAuth>} />
      <Route path="/dashboard/projects"         element={<RequireAuth><Layout><Projects /></Layout></RequireAuth>} />
      <Route path="/dashboard/education"        element={<RequireAuth><Layout><Education /></Layout></RequireAuth>} />
      <Route path="/dashboard/work"             element={<RequireAuth><Layout><WorkExperience /></Layout></RequireAuth>} />
      <Route path="/dashboard/certifications"   element={<RequireAuth><Layout><Certifications /></Layout></RequireAuth>} />
      <Route path="/dashboard/social"           element={<RequireAuth><Layout><SocialLinks /></Layout></RequireAuth>} />
      <Route path="/dashboard/reviews"          element={<RequireAuth><Layout><Reviews /></Layout></RequireAuth>} />
      <Route path="/dashboard/activities"       element={<RequireAuth><Layout><Activities /></Layout></RequireAuth>} />
      <Route path="/dashboard/problem-solving"  element={<RequireAuth><Layout><ProblemSolving /></Layout></RequireAuth>} />
      <Route path="/dashboard/messages"         element={<RequireAuth><Layout><Messages /></Layout></RequireAuth>} />
      <Route path="/dashboard/settings"         element={<RequireAuth><Layout><Settings /></Layout></RequireAuth>} />

      {/* ── Fallback ── */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#1c1c22', color: '#e8e8f0',
              border: '1px solid #2a2a35', borderRadius: '8px', fontSize: '0.875rem',
            },
            success: { iconTheme: { primary: '#5cb87e', secondary: '#1c1c22' } },
            error:   { iconTheme: { primary: '#e05c5c', secondary: '#1c1c22' } },
          }}
        />
      </AuthProvider>
    </BrowserRouter>
  )
}
