# PortfolioCMS — Frontend Dashboard

A complete React frontend for the PortfolioCMS .NET backend API.

## Route structure

| URL                        | Page                                         | Auth? |
|----------------------------|----------------------------------------------|-------|
| `/`                        | **Public portfolio landing page** (Hero, Skills, Work, Projects, Blog preview, Contact…) | ✗ |
| `/blog`                    | Paginated blog listing with search           | ✗     |
| `/blog/:slug`              | Individual blog post reader                  | ✗     |
| `/login`                   | Login                                        | ✗     |
| `/register`                | Register (with live username check)          | ✗     |
| `/forgot-password`         | Password reset request                       | ✗     |
| `/dashboard`               | Dashboard overview                           | ✓     |
| `/dashboard/profile`       | Profile (photo + resume upload, public toggle)| ✓    |
| `/dashboard/blog`          | Blog posts CRUD + publish/unpublish          | ✓     |
| `/dashboard/categories`    | Blog categories CRUD                         | ✓     |
| `/dashboard/skills`        | Skills CRUD                                  | ✓     |
| `/dashboard/projects`      | Projects CRUD                                | ✓     |
| `/dashboard/education`     | Education CRUD                               | ✓     |
| `/dashboard/work`          | Work experience CRUD                         | ✓     |
| `/dashboard/certifications`| Certifications CRUD                          | ✓     |
| `/dashboard/social`        | Social links CRUD                            | ✓     |
| `/dashboard/reviews`       | Testimonials CRUD                            | ✓     |
| `/dashboard/activities`    | Extra-curricular CRUD                        | ✓     |
| `/dashboard/problem-solving`| Competitive programming profiles CRUD       | ✓     |
| `/dashboard/messages`      | Contact messages inbox                       | ✓     |
| `/dashboard/settings`      | Change name, password, delete account        | ✓     |

## Getting started

```bash
# 1. Install
npm install

# 2. Configure
cp .env.example .env
```

Edit `.env`:
```
VITE_API_URL=http://localhost:5000/api/v1
VITE_PORTFOLIO_USERNAME=your_username_here
```

`VITE_PORTFOLIO_USERNAME` is the username whose public data drives the `/` portfolio page and `/blog` pages. Set it to your own username.

```bash
# 3. Dev server
npm run dev          # → http://localhost:5173

# 4. Production build
npm run build
```

## Tech stack

| Tool | Version | Purpose |
|---|---|---|
| React | 19 | UI |
| Vite | 8 | Build tooling |
| React Router | 7 | Client-side routing |
| Axios | latest | HTTP + JWT interceptors + auto-refresh |
| react-hot-toast | latest | Toast notifications |
| lucide-react | latest | Icons |
| date-fns | latest | Date formatting |
