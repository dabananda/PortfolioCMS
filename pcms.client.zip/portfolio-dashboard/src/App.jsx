import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider, useAuth } from './context/AuthContext'
import Layout from './components/layout/Layout'

import Login from './pages/auth/Login'
import Register from './pages/auth/Register'
import ForgotPassword from './pages/auth/ForgotPassword'

import Dashboard from './pages/dashboard/Dashboard'
import Profile from './pages/dashboard/Profile'
import BlogPosts from './pages/dashboard/BlogPosts'
import Categories from './pages/dashboard/Categories'
import Skills from './pages/dashboard/Skills'
import Projects from './pages/dashboard/Projects'
import Education from './pages/dashboard/Education'
import WorkExperience from './pages/dashboard/WorkExperience'
import Certifications from './pages/dashboard/Certifications'
import SocialLinks from './pages/dashboard/SocialLinks'
import Reviews from './pages/dashboard/Reviews'
import Activities from './pages/dashboard/Activities'
import ProblemSolving from './pages/dashboard/ProblemSolving'
import Messages from './pages/dashboard/Messages'
import Settings from './pages/dashboard/Settings'

function PrivateRoute({ children }) {
  const { isAuthenticated } = useAuth()
  return isAuthenticated ? children : <Navigate to="/login" replace />
}

function PublicRoute({ children }) {
  const { isAuthenticated } = useAuth()
  return isAuthenticated ? <Navigate to="/dashboard" replace /> : children
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
      <Route path="/register" element={<PublicRoute><Register /></PublicRoute>} />
      <Route path="/forgot-password" element={<PublicRoute><ForgotPassword /></PublicRoute>} />
      <Route path="/dashboard" element={<PrivateRoute><Layout><Dashboard /></Layout></PrivateRoute>} />
      <Route path="/dashboard/profile" element={<PrivateRoute><Layout><Profile /></Layout></PrivateRoute>} />
      <Route path="/dashboard/blog" element={<PrivateRoute><Layout><BlogPosts /></Layout></PrivateRoute>} />
      <Route path="/dashboard/categories" element={<PrivateRoute><Layout><Categories /></Layout></PrivateRoute>} />
      <Route path="/dashboard/skills" element={<PrivateRoute><Layout><Skills /></Layout></PrivateRoute>} />
      <Route path="/dashboard/projects" element={<PrivateRoute><Layout><Projects /></Layout></PrivateRoute>} />
      <Route path="/dashboard/education" element={<PrivateRoute><Layout><Education /></Layout></PrivateRoute>} />
      <Route path="/dashboard/work" element={<PrivateRoute><Layout><WorkExperience /></Layout></PrivateRoute>} />
      <Route path="/dashboard/certifications" element={<PrivateRoute><Layout><Certifications /></Layout></PrivateRoute>} />
      <Route path="/dashboard/social" element={<PrivateRoute><Layout><SocialLinks /></Layout></PrivateRoute>} />
      <Route path="/dashboard/reviews" element={<PrivateRoute><Layout><Reviews /></Layout></PrivateRoute>} />
      <Route path="/dashboard/activities" element={<PrivateRoute><Layout><Activities /></Layout></PrivateRoute>} />
      <Route path="/dashboard/problem-solving" element={<PrivateRoute><Layout><ProblemSolving /></Layout></PrivateRoute>} />
      <Route path="/dashboard/messages" element={<PrivateRoute><Layout><Messages /></Layout></PrivateRoute>} />
      <Route path="/dashboard/settings" element={<PrivateRoute><Layout><Settings /></Layout></PrivateRoute>} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#1c1c22',
              color: '#e8e8f0',
              border: '1px solid #2a2a35',
              borderRadius: '8px',
              fontSize: '0.875rem',
            },
            success: { iconTheme: { primary: '#5cb87e', secondary: '#1c1c22' } },
            error: { iconTheme: { primary: '#e05c5c', secondary: '#1c1c22' } },
          }}
        />
      </AuthProvider>
    </BrowserRouter>
  )
}
