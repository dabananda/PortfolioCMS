# PortfolioCMS — Frontend Dashboard

A complete React dashboard for the PortfolioCMS .NET backend API.

## Tech Stack
- **React 19** + **Vite 8** — fast modern build tooling
- **React Router v7** — client-side routing with protected routes
- **Axios** — HTTP client with JWT interceptors & auto-refresh
- **react-hot-toast** — elegant notifications
- **lucide-react** — consistent icon set
- **date-fns** — date formatting

## Features
| Section | Capabilities |
|---|---|
| **Auth** | Login, Register (with live username check), Forgot Password |
| **Dashboard** | Stats overview, recent posts, unread message alerts |
| **Profile** | Create/update profile, photo + resume upload, public toggle |
| **Blog Posts** | Full CRUD, publish/unpublish toggle, category assignment, search |
| **Categories** | Manage blog categories |
| **Skills** | Add skills with proficiency level & progress bar |
| **Projects** | Showcase projects with tech tags, GitHub & live links |
| **Education** | Academic history with CGPA/scale |
| **Work Experience** | Job history with role descriptions |
| **Certifications** | Credentials with issuer, date, ID, URL |
| **Social Links** | All your social profiles |
| **Reviews** | Client/colleague testimonials with star ratings |
| **Activities** | Extra-curricular activities |
| **Problem Solving** | Competitive programming profiles (LeetCode etc.) |
| **Messages** | Inbox with read/unread states, reply via email |
| **Settings** | Update name, change password, delete account (with confirmation) |

## Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Set your API URL
cp .env.example .env
# Edit VITE_API_URL in .env to point to your backend

# 3. Start dev server
npm run dev
# → http://localhost:5173

# 4. Production build
npm run build
```

## Environment Variables
```
VITE_API_URL=http://localhost:5000/api/v1
```

## Project Structure
```
src/
├── api/          # All API service modules (axios)
├── components/
│   ├── ui/       # Reusable UI: Button, Card, Modal, Field, Badge...
│   ├── layout/   # Sidebar + main layout
│   └── ResourcePage.jsx  # Generic CRUD page factory
├── context/      # AuthContext (JWT + localStorage)
├── hooks/        # useCrud hook
└── pages/
    ├── auth/     # Login, Register, ForgotPassword
    └── dashboard/ # All 15 dashboard pages
```
